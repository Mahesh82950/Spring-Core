package com.nit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.nit.model.Employee;
import com.nit.repo.IEmployeeRepo;

@Service("empServie")
public class EmployeeReportServiceImpl implements IEmoployeeReportService {

	@Autowired
	private IEmployeeRepo repo;
	

	@Override
	public String addEmployee(Employee emp) {
		Integer id=repo.save(emp).getEid();
		return "ID No :: "+id+" Employee Registered SuccessFully..";
	}

	@Override
	public Employee editEmployee(Integer id) {
		Employee emp=repo.findById(id).get();
		return emp;
	}

	@Override
	public String editEmployee(Employee emp) {
		Integer id=repo.save(emp).getEid();
		return "Employee Updated of ID :: "+id;
	}

	@Override
	public String deletEmployee(Integer id) {
		repo.deleteById(id);
		return id+" :: ID Employee Deleted...";
	}

	@Override
	public Page<Employee> getAllEmployee(Pageable pageable) {
		Page<Employee> page=repo.findAll(pageable);
		return page;
	}

}
