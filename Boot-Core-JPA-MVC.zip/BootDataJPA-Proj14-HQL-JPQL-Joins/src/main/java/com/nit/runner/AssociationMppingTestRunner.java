package com.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.service.IPersonMngService;

@Component
public class AssociationMppingTestRunner implements CommandLineRunner {
@Autowired
private IPersonMngService service;
	@Override
	public void run(String... args) throws Exception {

		try {
			service.fetchDataByJoins().forEach(obj->{
				for(Object o:obj) {
					System.out.print(o+" ");
				}
				System.out.println();
			});
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
