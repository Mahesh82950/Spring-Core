package com.nit.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nit.entity.Person;

public interface IPersonMngDao extends JpaRepository<Person, Integer> {

//	@Query("select per.pid,per.pname,per.paddr,ph.regNo,ph.phoneNumber,ph.phoneNumber,ph.provider from Person per left join per.phNumber ph")
//	@Query("select per.pid,per.pname,per.paddr,ph.regNo,ph.phoneNumber,ph.phoneNumber,ph.provider from Person per right join per.phNumber ph")
//	@Query("select per.pid,per.pname,per.paddr,ph.regNo,ph.phoneNumber,ph.phoneNumber,ph.provider from Person per join per.phNumber ph")
	@Query("select per.pid,per.pname,per.paddr,ph.regNo,ph.phoneNumber,ph.phoneNumber,ph.provider from Person per left join per.phNumber ph union select per.pid,per.pname,per.paddr,ph.regNo,ph.phoneNumber,ph.phoneNumber,ph.provider from Person per right join per.phNumber ph")

	public List<Object[]> getDataByJoins();
}
