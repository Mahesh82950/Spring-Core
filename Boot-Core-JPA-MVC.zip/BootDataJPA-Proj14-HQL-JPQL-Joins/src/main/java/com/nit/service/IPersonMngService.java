package com.nit.service;

import java.util.List;

public interface IPersonMngService {
public List<Object[]> fetchDataByJoins();
}
