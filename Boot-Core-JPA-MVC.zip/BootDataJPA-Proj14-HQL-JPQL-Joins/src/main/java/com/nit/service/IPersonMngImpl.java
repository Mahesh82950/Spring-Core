package com.nit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.dao.IPersonMngDao;
import com.nit.entity.Person;

@Service("empService")
public class IPersonMngImpl implements IPersonMngService {

	@Autowired
	private IPersonMngDao dao;

	@Override
	public List<Object[]> fetchDataByJoins() {
		return dao.getDataByJoins();
	}
	

}
