package com.nit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.nit.document.Cricketer;
import com.nit.repository.ICricketerRepo;

@Service("crktService")
public class CricketerServiceImpl implements ICricketerService {

	@Autowired
	private ICricketerRepo repo;
	
	@Override
	public String registerCricketer(Cricketer cricketer) {
		return repo.insert(cricketer).getJNumber()+" Jersey Number cricketer Registerd SuccessFully...";
	}

	@Override
	public List<Cricketer> getCricketerByCricketer(Cricketer cricketer, Boolean asc, String... prop) {
		Example example=Example.of(cricketer);
		Sort sort=Sort.by(asc?Direction.ASC:Direction.DESC,prop);
		return repo.findAll(example, sort);
	}

	@Override
	public List<Cricketer> getCricketerByCricketer(Cricketer cricketer) {
		Example example=Example.of(cricketer);
		return repo.findAll(example);
	}

	@Override
	public List<Cricketer> getAllCricketer() {
		
		return repo.findAll();
	}

	@Override
	public String bancricketer(Integer id) {
		Optional<Cricketer> opt=repo.findById(id);
		if(opt.isPresent()) {
		repo.deleteById(id);
		return "Cricketer Is Banned...";
		}
		return "Cricketer Not Found With given Id :: "+id;
	}


	@Override
	public String modifyCricketersAvrg(Integer id, Double avg) {
		Optional<Cricketer> opt=repo.findById(id);
		if(opt.isPresent()) {
			Cricketer cricketer=opt.get();
			cricketer.setAvrg(avg);
			repo.save(cricketer);
			return "Average of Cricketer is Modified to ::"+avg;
		}
		return "Cricketer Not Found With Given Id :: "+id;
	}

}
