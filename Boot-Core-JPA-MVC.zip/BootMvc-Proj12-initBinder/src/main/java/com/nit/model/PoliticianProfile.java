package com.nit.model;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class PoliticianProfile implements Serializable{

	private Integer pid;
	private String pname;
	private String party;
	private Date dob;
	private Date jod;
	private boolean consPost=false;
	
}
