package com.nit.controller;

import java.text.SimpleDateFormat;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.WebBindingInitializer;

import com.nit.model.PoliticianProfile;

@Controller
public class PoliticianProfileController {

	@GetMapping("/")
	public String welcomePage() {
		return "home";
	}
	
	@GetMapping("/register")
	public String registerPolitician(@ModelAttribute("pp")PoliticianProfile profile) {
		return "register_poli";
	}
	
	@PostMapping("/register")
	public String registerPoliticianData(@ModelAttribute("pp")PoliticianProfile profile) {
		
		System.out.println(profile);
		return "show_register_poli";
	}
	
	@InitBinder
	public void myInitBinder(WebDataBinder binder) {
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(java.util.Date.class, new CustomDateEditor(format, true));
	}
	
	
	
}
