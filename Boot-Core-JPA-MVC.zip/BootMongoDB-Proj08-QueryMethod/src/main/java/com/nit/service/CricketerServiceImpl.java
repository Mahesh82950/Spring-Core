package com.nit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.nit.document.Cricketer;
import com.nit.repository.ICricketerRepo;

@Service("crktService")
public class CricketerServiceImpl implements ICricketerService {

	@Autowired
	private ICricketerRepo repo;

	@Override
	public List<Cricketer> fetchAllCricketerByCountry(String country) {
		
		return repo.fetchAllCricketerByCountry1(country);
	}

	@Override
	public List<Cricketer> fetchAllCricketerByCountryAndJersey(String country, Integer jersey) {
		
		return repo.fetchAllCricketerByCountryAndJNumber(country, jersey);
	}

	@Override
	public List<Cricketer> fetchAllCricketerByAvrgRange(Double avg1, Double avg2) {
		return repo.fetchAllCricketerByAvrgRange(avg1, avg2);
	}

	@Override
	public List<Object[]> fetchAllCricketerByCountry_1(String country) {
		return repo.fetchAllCricketerByCountry_1(country);
	}

	@Override
	public List<Object[]> findPlayersInAvrage(Double avrg1, Double avrg2) {
		return repo.findPlayersInAvrage(avrg1, avrg2);
	}

	@Override
	public List<Object[]> fetchPlayerByCenturies(Integer centuries) {
		return repo.fetchPlayerByCenturies(centuries);
	}
	
	
}
