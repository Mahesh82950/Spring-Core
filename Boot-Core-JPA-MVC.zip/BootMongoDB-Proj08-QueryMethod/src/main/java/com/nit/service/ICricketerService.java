package com.nit.service;

import java.util.List;

import com.nit.document.Cricketer;

public interface ICricketerService {

	public List<Cricketer> fetchAllCricketerByCountry(String country);
	
	public List<Cricketer> fetchAllCricketerByCountryAndJersey(String country,Integer jersey);
	
	public List<Cricketer> fetchAllCricketerByAvrgRange(Double avg1,Double avg2);

	
	
	public List<Object[]> fetchAllCricketerByCountry_1(String country);
	public List<Object[]> findPlayersInAvrage(Double avrg1,Double avrg2);
	public List<Object[]> fetchPlayerByCenturies(Integer centuries);



	
}
