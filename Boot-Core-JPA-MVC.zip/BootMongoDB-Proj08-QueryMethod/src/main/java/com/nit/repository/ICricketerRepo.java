package com.nit.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nit.document.Cricketer;

public interface ICricketerRepo extends MongoRepository<Cricketer, String> {

	@Query(value = "{country:?0}")
	public List<Cricketer> fetchAllCricketerByCountry(String country);
	
	@Query(fields = "{}",value =  "{country:?0}")
	public List<Cricketer> fetchAllCricketerByCountry1(String country);
	
	@Query(value =  "{country:?0,JNumber:{$gte:?1}}")
	public List<Cricketer> fetchAllCricketerByCountryAndJNumber(String country,Integer jersey);
	
	@Query(value =  "{avrg:{$gte:?0},avrg{$lte:?1}}")
	public List<Cricketer> fetchAllCricketerByAvrgRange(Double avg1,Double avg2);
	
	@Query(fields = "{JNumber:1,name:1,nickname:1,centuries:1}",value = "{country:?0}")
	public List<Object[]> fetchAllCricketerByCountry_1(String country);

	@Query(fields = "{id:0,JNumber:1,name:1,nickname:1,centuries:1,avrg:1}",value = "{avrg :{$in:[?0,?1]}}")	
	public List<Object[]> findPlayersInAvrage(Double avrg1,Double avrg2);
	
	@Query(fields = "{name:1,centuries:1,avrg:1}",value = "{centuries:{$gte:?0}}")
	public List<Object[]> fetchPlayerByCenturies(Integer centuries);
	}
