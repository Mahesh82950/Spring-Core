package com.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.document.Cricketer;
import com.nit.service.ICricketerService;

@Component
public class CricketerTestRunner implements CommandLineRunner {

	@Autowired
	private ICricketerService service;
	@Override
	public void run(String... args) throws Exception {
//		service.fetchAllCricketerByCountry("India").forEach(cricketer -> {
//		    System.out.println(cricketer);
//		});
//		
//		System.out.println("================================================");
//		
//		service.fetchAllCricketerByCountryAndJersey("India",18).forEach(cricketer -> {
//		    System.out.println(cricketer);
//		});
//		System.out.println("=============================================");
//		service.fetchAllCricketerByAvrgRange(50.1, 58d).forEach(System.out::println);
//		System.out.println("=======================================================");
//		
//		service.fetchAllCricketerByCountry_1("India").forEach(emp->{
//			for(Object c:emp) {
//				System.out.println(c);
//			}
//		});
//        System.out.println("=======================================================");
//		
//		service.findPlayersInAvrage(45.0, 55.0).forEach(emp->{
//			for(Object c:emp) {
//				System.out.println(c);
//			}
//		});
        System.out.println("=======================================================");
		
		service.fetchPlayerByCenturies(30).forEach(emp->{
			for(Object c:emp) {
				System.out.println(c);
			}
		});
	}

}
