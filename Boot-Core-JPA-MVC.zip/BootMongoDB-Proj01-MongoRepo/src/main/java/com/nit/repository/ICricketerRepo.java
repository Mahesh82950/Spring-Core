package com.nit.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.nit.document.Cricketer;

public interface ICricketerRepo extends MongoRepository<Cricketer, String> {

	}
