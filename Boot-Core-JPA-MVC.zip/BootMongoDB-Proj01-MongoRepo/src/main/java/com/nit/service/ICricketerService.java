package com.nit.service;

import java.util.List;

import com.nit.document.Cricketer;

public interface ICricketerService {

	public String registerCricketer(Cricketer cricketer);
	public List<Cricketer> getCricketerByCricketer(Cricketer cricketer,Boolean asc,String...prop);
	public List<Cricketer> getCricketerByCricketer(Cricketer cricketer);
	public List<Cricketer> getAllCricketer();
	public String bancricketer(String id);
	public String modifyCricketersAvrg(String id,Double avg);
}
