function validation(frm) {
	document.getElementById("enameErr").innerHTML = "";
	document.getElementById("jobErr").innerHTML = "";
	document.getElementById("salErr").innerHTML = "";

	let ename = frm.ename.value;
	let job = frm.job.value;
	let salary = frm.salary.value;
	let flag = true;

	if (ename == "") {
		document.getElementById("enameErr").innerHTML = "Employee name must provide(cs)";
		flag = false;
	}
	else if (ename.length > 10) {
		document.getElementById("enameErr").innerHTML = "Employee name can have max 10 chars(cs)";
		flag = false;
	}
	else if (job == "") {
		document.getElementById("jobErr").innerHTML = "Employee job must provide(cs)";
		flag = false;
	}
	else if (job.length > 10) {
		document.getElementById("jobErr").innerHTML = "Employee job can have max 10 chars(cs)";
		flag = false;
	}
	else if (salary == "") {
		document.getElementById("salErr").innerHTML = "Employee Salary must provide(cs)";
		flag = false;
	}
	else if (isNaN(salary)) {
		document.getElementById("salErr").innerHTML = "Employee Salary must Numeric value(cs)";
		flag = false;
	}
	else if (salary <= 0 || salary > 1000000) {
		document.getElementById("salErr").innerHTML = "Employee Salary must in range through 1 to 1000000(cs)";
		flag = false;
	}
    frm.vFlag.value="yes";

	return flag;
}