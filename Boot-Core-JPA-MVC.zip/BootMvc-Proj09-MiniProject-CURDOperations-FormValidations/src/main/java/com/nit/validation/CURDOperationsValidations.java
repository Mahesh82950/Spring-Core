package com.nit.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.nit.model.Employee;

@Component
public class CURDOperationsValidations implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		
		return clazz.isAssignableFrom(Employee.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		Employee emp=(Employee)target;
		
		if(emp.getEname()==null||emp.getEname().length()==0||emp.getEname().equals("")) {
			errors.rejectValue("ename", "empname.required");
		}
		else if(emp.getEname().length()>10) {
			errors.rejectValue("ename", "empname.maxLength");
		}
		if(emp.getJob()==null||emp.getJob().length()==0||emp.getJob().equals("")) {
			errors.rejectValue("job", "empjob.required");
		}
		else if(emp.getJob().length()>10) {
			errors.rejectValue("job", "empjob.maxLength");
		}
		if(emp.getSalary()==null) {
			errors.rejectValue("salary", "empsalary.required");
		}
		else if(emp.getSalary()<1||emp.getSalary()>1000000) {
			errors.rejectValue("salary", "empsalary.range");
		}
	}

}
