package com.nit.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DataBindingRequestParam {

	
//	@GetMapping("/reg")
//	public String registerEmp(@RequestParam("sno")int sno,@RequestParam("sname")String sname) {
//		System.out.println(sno+" "+sname);
//		return "GetReg";
//	}
//	@GetMapping("/reg")
//	public String registerEmp(@RequestParam int sno,@RequestParam String sname) {
//		System.out.println(sno+" "+sname);
//		return "GetReg";
//	}
//	@GetMapping("/reg")
//	public String registerEmp(@RequestParam int sno,@RequestParam(required = false) String sname) {
//		System.out.println(sno+" "+sname);//required = false will protect from exception 
//		//if we give wrong param name(sname--name) while writing in browser it will throw exception
//		return "GetReg";
//	}
	
//	@GetMapping("/reg")
//	public String registerEmp(@RequestParam int sno,@RequestParam(defaultValue = "Ram") String sname) {
//		System.out.println(sno+" "+sname);//defaultValue = "Ram" will provide default value in eclips if we forgot or given wrong param name
//		return "GetReg";
//	}
	
	@GetMapping("/reg")
	public String registerEmp(@RequestParam(name="sno",required = false)int sno,@RequestParam("sname") String sname,
			@RequestParam("sadd")String addr[],@RequestParam("sadd")List<String> laddr,@RequestParam("sadd")Set<String> saddr) {
		System.out.println(sno+" "+sname+" "+Arrays.toString(addr)+" \n"+laddr+"\n"+saddr);
		return "GetReg";
	}
	
	
	
	
	
}
