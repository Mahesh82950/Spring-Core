package com.nit.service;

import java.util.List;

import com.nit.model.Employee;

public interface IEmoployeeReportService {

	public List<Employee> getAllEmployee();
	
	public String addEmployee(Employee emp);
	
	public Employee editEmployee(Integer id);
	
	public String editEmployee(Employee emp);
	
	public String deletEmployee(Integer id);
	public List<Employee> searchEmployee(Employee emp);
	}
