package com.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.nit.entity.Docter;
import com.nit.service.IDocterService;

@SpringBootApplication
public class BootDataJpaProj01CrudRepository1Application {

	public static void main(String[] args) {
		ApplicationContext ctx=SpringApplication.run(BootDataJpaProj01CrudRepository1Application.class, args);
//		IDocterService docterService=ctx.getBean("DocterService", IDocterService.class);
//		Docter docter=new Docter();
//		docter.setDocName("Natraz");
//		docter.setSpecification("Psycologist");
//		docter.setIncome(80000D);
//		try {
//			//System.out.println(docterService.registerDocter(docter));
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
//		try {
//			System.out.println("Total Number of Registered Docters Are ::"+docterService.getTotalCount());
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
	}

}
