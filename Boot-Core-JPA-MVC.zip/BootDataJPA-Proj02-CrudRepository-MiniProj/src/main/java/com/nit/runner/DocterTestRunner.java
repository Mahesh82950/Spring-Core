package com.nit.runner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.entity.Docter;
import com.nit.service.IDocterService;

@Component
public class DocterTestRunner implements CommandLineRunner{

	@Autowired
	private IDocterService docterService;
	@Override
	public void run(String... args) throws Exception {
		System.out.println("=====================================================");
		
		Docter docter=new Docter();
		docter.setDocName("Nithin");
		docter.setIncome(70000d);
		docter.setSpecification("Heart Specilist");
		
		//System.out.println(docterService.registerDocter(docter));
		System.out.println("=====================================================");
		
		//System.out.println("Number of docters rigistered Are :: "+docterService.getTotalCount());
		
		System.out.println("=====================================================");
		
		//System.out.println(docterService.deleteDocterById(3));
		System.out.println("=====================================================");
		
//		List<Docter> list=(List<Docter>) docterService.getAllDocters();
//		list.forEach(System.out::println);
		System.out.println("=====================================================");
		
		docterService.getAllDoctersById(List.of(1,2)).forEach(System.out::println);

		System.out.println("=====================================================");
		
		System.out.println(docterService.getDocterById(4));
		System.out.println("=====================================================");
		
		System.out.println(docterService.checkDocterPresentOrNot(2));
		System.out.println("=====================================================");
		
		//System.out.println(docterService.deleteAllDocters(List.of(4,2)));
		System.out.println("=====================================================");



		
	}

}
