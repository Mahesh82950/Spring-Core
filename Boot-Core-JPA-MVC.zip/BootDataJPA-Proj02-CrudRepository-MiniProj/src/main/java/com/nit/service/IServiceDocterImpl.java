package com.nit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.entity.Docter;
import com.nit.repository.IDocterRepository;

@Service("DocterService")
public class IServiceDocterImpl implements IDocterService {
	@Autowired
	private IDocterRepository docterRepository;

	@Override
	public String registerDocter(Docter docter) {
		Docter doc=docterRepository.save(docter);
		//System.out.println("Docter Info:: "+docter);
		return "Docter Registered with Id :: "+doc.getDocId();
	}

	@Override
	public long getTotalCount() {
		
		return docterRepository.count();
	}

	@Override
	public String deleteDocterById(Integer id) {
		Optional<Docter> opt=docterRepository.findById(id);
		if(opt.isPresent()) {
			docterRepository.deleteById(id);
			return "Docter with the Id Number :: "+id+" is Deleted...";
		}
		
		return "Invalid Id....Docter Not Found...";
	}

	@Override
	public String deleteAllDocters(List<Integer> list) {
		docterRepository.deleteAll();
		return "All the Docters are Deleted....";
	}

	@Override
	public Iterable<Docter> getAllDocters() {
		
		return docterRepository.findAll();
	}

	@Override
	public Iterable<Docter> getAllDoctersById(List<Integer> list) {
		
		return docterRepository.findAllById(list);
	}

	@Override
	public Docter getDocterById(Integer id) {
		return docterRepository.findById(id).orElseThrow(()->new IllegalArgumentException("Docter Not Found With Given Id..."));
	}

	@Override
	public String checkDocterPresentOrNot(Integer id) {
		if(docterRepository.existsById(id)) {
			return "Docter is Avilable With the Given Id Of :: "+id;
		}
		return "Docter is Not Avilable With the Given Id Of :: "+id;
	}

}
