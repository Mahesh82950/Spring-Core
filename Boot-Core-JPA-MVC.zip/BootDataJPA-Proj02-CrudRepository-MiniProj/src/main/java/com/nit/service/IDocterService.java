package com.nit.service;

import java.util.List;

import com.nit.entity.Docter;

public interface IDocterService {
	public String registerDocter(Docter docter);
	public long getTotalCount();
	public String deleteDocterById(Integer id);
	public String deleteAllDocters(List<Integer> list);
	public Iterable<Docter> getAllDocters();
	public Iterable<Docter> getAllDoctersById(List<Integer> list);
	public Docter getDocterById(Integer id);
	public String checkDocterPresentOrNot(Integer id);

}
