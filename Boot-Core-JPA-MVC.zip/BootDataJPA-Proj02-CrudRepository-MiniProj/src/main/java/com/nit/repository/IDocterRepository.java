package com.nit.repository;

import org.springframework.data.repository.CrudRepository;

import com.nit.entity.Docter;

public interface IDocterRepository extends CrudRepository<Docter, Integer> {

}
