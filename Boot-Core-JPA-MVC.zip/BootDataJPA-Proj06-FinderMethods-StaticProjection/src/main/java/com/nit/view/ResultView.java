package com.nit.view;

public interface ResultView {

	public String getmNAme();
	public Integer getMid();
}
