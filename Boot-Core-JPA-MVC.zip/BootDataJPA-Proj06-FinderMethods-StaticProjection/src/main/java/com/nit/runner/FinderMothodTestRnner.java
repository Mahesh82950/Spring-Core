package com.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.repository.IMovieRepository;
import com.nit.view.ResultView;

@Component
public class FinderMothodTestRnner implements CommandLineRunner{

	@Autowired
	private IMovieRepository iMovieMngtService;
	@Override
	public void run(String... args) throws Exception {

		System.out.println("===============================================");
		Iterable<ResultView> it=iMovieMngtService.findByMidGreaterThanEqualAndMidLessThanEqual(11, 25);
		it.forEach(view->{
			System.out.println(view.getmNAme()+"  "+view.getMid()+"\n");
			System.out.println("===================================");
			
		});
		
	}

}
