package com.nit.document;

import java.util.Map;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;

@Document
@Setter
@Getter
public class Player {

	@Id
	private String pid;
	private String pnmae;
	private String padd;
	private Integer page;
	
	private Set<Sport> sport;
	private Map<String,Medals> medals;
	@Override
	public String toString() {
		return "Player [pid=" + pid + ", pnmae=" + pnmae + ", padd=" + padd + ", age=" + page + "]";
	}
	
	
}
