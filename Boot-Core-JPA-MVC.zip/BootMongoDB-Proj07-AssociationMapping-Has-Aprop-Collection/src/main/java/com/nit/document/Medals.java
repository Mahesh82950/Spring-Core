package com.nit.document;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;

@Document
@Setter
@Getter
public class Medals {

	@Id
	private Integer mid;
	private String mname; 
	private String event;
	@Override
	public String toString() {
		return "Medals [mid=" + mid + ", mname=" + mname + ", event=" + event + "]";
	}
	
	
	 
}
