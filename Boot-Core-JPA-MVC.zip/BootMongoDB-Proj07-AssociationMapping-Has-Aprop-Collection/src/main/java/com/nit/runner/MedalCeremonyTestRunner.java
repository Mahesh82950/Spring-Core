package com.nit.runner;

import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.document.Medals;
import com.nit.document.Player;
import com.nit.document.Sport;
import com.nit.service.IMedalCeremonyService;

@Component
public class MedalCeremonyTestRunner implements CommandLineRunner {

	@Autowired
	private IMedalCeremonyService service;
	@Override
	public void run(String... args) throws Exception {
		
		Medals medal=new Medals();
		medal.setMid(new Random().nextInt(1000000));
		medal.setEvent("Tokio Olimpik");
		medal.setMname("Gold");
		Medals medal1=new Medals();
		medal1.setMid(new Random().nextInt(1000000));
		medal1.setEvent("Reo Olimpik");
		medal1.setMname("Silver");
		
		Sport sport=new Sport();
		sport.setSid(new Random().nextInt(1000000));
		sport.setSname("Badminton");
		sport.setKitItems(new String[] {"racket","Cock","net"});
		Sport sport1=new Sport();
		sport1.setSid(new Random().nextInt(1000000));
		sport1.setSname("Tennis");
		sport1.setKitItems(new String[] {"racket","ball","net"});
		
		
		Player player= new Player();
		player.setPnmae("K.Shrikant");
		player.setPage(32);
		player.setPadd("India");
		player.setSport(Set.of(sport,sport1));
		player.setMedals(Map.of("medal1",medal,"medal2",medal1));
		
//		System.out.println(service.registerPlayer(player));
		service.fetchAllPlayers().forEach(emp->{
			System.out.println(emp);
			System.out.println(emp.getMedals()+"\n"+emp.getSport());
			System.out.println();
		});
	}

}
