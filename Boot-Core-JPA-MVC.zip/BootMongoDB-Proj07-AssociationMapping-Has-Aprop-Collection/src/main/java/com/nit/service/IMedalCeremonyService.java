package com.nit.service;

import java.util.List;

import com.nit.document.Player;

public interface IMedalCeremonyService {

	public String registerPlayer(Player player);
	public List<Player> fetchAllPlayers();
}
