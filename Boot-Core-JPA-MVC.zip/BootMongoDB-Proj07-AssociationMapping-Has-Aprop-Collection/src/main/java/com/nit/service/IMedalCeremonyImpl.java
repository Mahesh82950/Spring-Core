package com.nit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.document.Player;
import com.nit.repository.IMedalsRepository;
import com.nit.repository.IPlayerRepository;
import com.nit.repository.ISportRepository;

@Service("medalService")
public class IMedalCeremonyImpl implements IMedalCeremonyService {

	@Autowired
	private IPlayerRepository playerRepository;
	@Autowired
	private IMedalsRepository medalsRepository;
	@Autowired
	private ISportRepository sportRepository;
	@Override
	public String registerPlayer(Player player) {
		
		return playerRepository.save(player).getPid()+" Id Player Is Registered...";
	}
	@Override
	public List<Player> fetchAllPlayers() {
		return playerRepository.findAll();
	}

}
