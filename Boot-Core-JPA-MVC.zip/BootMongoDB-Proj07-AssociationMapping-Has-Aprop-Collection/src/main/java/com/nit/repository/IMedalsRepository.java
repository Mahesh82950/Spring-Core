package com.nit.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.nit.document.Medals;

public interface IMedalsRepository extends MongoRepository<Medals, Integer> {

}
