package com.nit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nit.entity.Movie;

public interface IMovieRepository extends JpaRepository<Movie,Integer> {
//with @Query method we can only perform select operations....if we use   @Modifying then we can do both
	@Query("from Movie where mid>=:mid1 and mid<=:mid2")
	public List<Movie> searchMovieByIdRange(int mid1,int mid2);
	
	@Query("from Movie")
	public List<Movie> getAllMovies();
	
	@Query("from Movie where year=:param")
	public List<Movie> searchMovieByYear(int param);
	
	@Query("from Movie where rating=(select max(rating) from Movie)")
	public List<Movie> searchMovieByMaxRating();
	
	@Query("select mNAme from Movie where mid=:id")
	public String getMovieNameById(int id);
	
	@Query("select mNAme,year,rating from Movie where mNAme=:name")
	public List<Object[]> fetchSpecificMovieData(String name);
	
	@Query("select max(mid),max(rating),avg(mid),count(*) from Movie")
	public Object getAggrigateDataOnMovie();
	
	
	@Query("from Movie where year>=:year1 and rating<=:rating1")
	public List<Movie> fetchMovieBYCondition(int year1,float rating1);
	
	@Query("FROM Movie WHERE mNAme LIKE CONCAT(:ch,'%')")
	public List<Movie> fetchMovieByFirstLetter(String ch);
	
	@Query("FROM Movie WHERE mNAme LIKE CONCAT('%',:ch)")
	public List<Movie> fetchMovieByLastLetter(String ch);
}
