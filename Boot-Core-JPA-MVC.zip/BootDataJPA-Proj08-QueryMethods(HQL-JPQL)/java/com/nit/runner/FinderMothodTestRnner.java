package com.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.repository.IMovieRepository;

@Component
public class FinderMothodTestRnner implements CommandLineRunner {

	@Autowired
	private IMovieRepository iMovieMngtService;

	@Override
	public void run(String... args) throws Exception {

//		System.out.println("===============================================");
//		
//		iMovieMngtService.searchMovieByIdRange(20,30).forEach(System.out::println);
//	}

		System.out.println("===============================================");

//		iMovieMngtService.getAllMovies().forEach(System.out::println);
//
//		System.out.println("===============================================");
//
//		iMovieMngtService.searchMovieByYear(2022).forEach(System.out::println);
//		System.out.println("===============================================");
//
//		iMovieMngtService.searchMovieByMaxRating().forEach(System.out::println);
//		
//		System.out.println("===========================================");
//		System.out.println(iMovieMngtService.getMovieNameById(12));
//		
//		System.out.println("===========================================");
//		
		
		iMovieMngtService.fetchSpecificMovieData("Charlee").forEach(row->{
			for(Object val:row) {
				System.out.print(val+" ");
			}
		});
		
		
	System.out.println("===========================================");
//		
//		Object data1=iMovieMngtService.getAggrigateDataOnMovie();
//		Object[] obj1=(Object[]) data1;
//		
//		System.out.println("Max id :: "+obj1[0]);
//		System.out.println("Max rating :: "+obj1[1]);
//		System.out.println("Avg of Id :: "+obj1[2]);
//		System.out.println("count of Movies  :: "+obj1[3]);
//		
//		System.out.println("===============================================");
//		iMovieMngtService.fetchMovieBYCondition(2022,7f).forEach(System.out::println);
//		System.out.println("=================================");
//		iMovieMngtService.fetchMovieByFirstLetter("R").forEach(System.out::println);
//		
//		System.out.println("=================================");
//		iMovieMngtService.fetchMovieByLastLetter("a").forEach(System.out::println);
//		
		
	}
}
