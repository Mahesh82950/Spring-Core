package com.nit.document;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document
public class Person_Info implements Serializable{

	@Id
	private String id;
	private String name;
	private String add;
	private String[] hobbies;
	private List<String> friends;
	private Set<Long> contacts;
	private Map<String,Long> bankdetails;
	private Properties properties;
}
