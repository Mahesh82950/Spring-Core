package com.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMongoDbProj05CollectionMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMongoDbProj05CollectionMappingApplication.class, args);
	}

}
