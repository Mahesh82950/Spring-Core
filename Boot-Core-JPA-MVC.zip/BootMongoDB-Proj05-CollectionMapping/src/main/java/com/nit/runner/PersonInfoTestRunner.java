package com.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.service.IPersonInfoService;

@Component
public class PersonInfoTestRunner implements CommandLineRunner {
@Autowired
private IPersonInfoService service;
	@Override
	public void run(String... args) throws Exception {
//		Person_Info info=new Person_Info();
//		info.setName("mahesh");
//		info.setAdd("Hydrabad");
//		info.setFriends(List.of("marot","vicky","raju"));
//		info.setContacts(Set.of(11111111L,8888888888L));
//		info.setBankdetails(Map.of("SBI",4514561251L,"MGB",55121251210L));
//		Properties properties=new Properties();
//		properties.setProperty("java", "jaganath");
//		properties.setProperty("Advjava", "Mansani");
//		properties.setProperty("oracle", "AshokIt(mahesh sir)");
//		properties.setProperty("SBMS", "natraz");
//		info.setProperties(properties);
//		info.setHobbies(new String[] {"dancing","Watching Virat Kohli's Batting","Coding"});
//		System.out.println(service.registerPerson(info));
//		
		service.getAllpersonInfo().forEach(System.out::println);
		
/*		Person_Info(id=673608a44a371865cac47eb1, name=Natraj, add=Hydrabad, 
		hobbies=[dancing, Watching Virat Kohli's Batting, Coding], 
		friends=[murti, jaganath, praveen], contacts=[9999999999, 8888888888], 
		bankdetails={SBI=1646616466, ICICI=5466661541}, 
		properties={java=jaganath, oracle=AshokIt(mahesh sir), SBMS=natraz, Advjava=Mansani})
*/
	}

}
