package com.nit.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.nit.document.Person_Info;

public interface IPerson_InfoRepo extends MongoRepository<Person_Info, String> {

}
