package com.nit.service;

import java.util.List;

import com.nit.document.Person_Info;

public interface IPersonInfoService{
	public String registerPerson(Person_Info info);
	public List<Person_Info> getAllpersonInfo();

}
