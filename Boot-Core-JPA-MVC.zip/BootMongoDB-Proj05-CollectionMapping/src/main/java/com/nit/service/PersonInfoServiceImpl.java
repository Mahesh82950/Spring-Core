package com.nit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.document.Person_Info;
import com.nit.repository.IPerson_InfoRepo;

@Service("perService")
public class PersonInfoServiceImpl implements IPersonInfoService{

	@Autowired
	private IPerson_InfoRepo repo;
	
	@Override
	public String registerPerson(Person_Info info) {
		
		return repo.save(info).getId()+" :: With Id Person Is Registered...";
	}

	@Override
	public List<Person_Info> getAllpersonInfo() {
		return repo.findAll();
	}

	
}
