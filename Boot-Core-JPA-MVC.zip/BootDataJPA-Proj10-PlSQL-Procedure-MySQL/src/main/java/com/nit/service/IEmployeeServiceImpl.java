package com.nit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.entity.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;

@Service("empService")
public class IEmployeeServiceImpl implements IEmployeeService{

	@Autowired
	private EntityManager manager;

	@Override
	public List<Employee> fetchEmployeeByDesg(String desg1, String desg2) {
		StoredProcedureQuery query= manager.createStoredProcedureQuery("P_GET_EMP_BY_JOB", Employee.class);
		query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
		query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
		query.setParameter(1, desg1);
		query.setParameter(2, desg2);
		return query.getResultList();
	}

}
