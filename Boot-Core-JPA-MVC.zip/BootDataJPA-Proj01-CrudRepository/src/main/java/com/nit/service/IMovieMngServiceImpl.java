package com.nit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.entity.Movie;
import com.nit.repository.IMovieRepository;

@Service("imovieService")
public class IMovieMngServiceImpl implements IMovieMngtService {

	@Autowired
	private IMovieRepository  iMovieRepository;
	@Override
	public String registerMovie(Movie movie) {
		System.out.println(movie);
		Movie movie1=iMovieRepository.save(movie);
		System.out.println(movie1);
		return "Movir Registered With Movie Id :: "+movie1.getMid();
	}
	
	
	@Override
	public long countMovies() {
		
		return iMovieRepository.count();
	}
	
	
	@Override
	public boolean isMoviePresent(Integer mid) {
		
		return iMovieRepository.existsById(mid);
	}
	
	
	@Override
	public Iterable<Movie> fetchAllMovies() {
		return iMovieRepository.findAll();
	}
	
	
	@Override
	public Iterable<Movie> fetchMoviesByIds(List<Integer> ids) {
		
		return iMovieRepository.findAllById(ids);
	}
	
	
	
	@Override
	public Movie fetById(Integer mid) throws IllegalAccessException {
//		Optional<Movie> opt=iMovieRepository.findById(mid);
//		if(opt.isPresent()) {
//			return opt.get();
//		}
//		else {
//			throw new IllegalArgumentException("Movie Not Found...");
//		}
		return iMovieRepository.findById(mid).orElseThrow(()->new IllegalAccessException("Record Not Found"));
	}
	
	
	
	
	@Override
	public String removeAllMoviesById(List<Integer> list) {
		Iterable<Movie> it=iMovieRepository.findAllById(list);
		int count=((List<Movie>) it).size();
		if(list.size()!=0&&list.size()==count) {
			iMovieRepository.deleteAllById(list);
			return list.toString()+" id's movies With The Size of ...."+((List<Movie>) it).size()+" Are deleted";
		}
		return "id Not Found To Perform Delete Opratin...";
	}
	
	
	
	
	@Override
	public String deleteMovieById(Integer id) {
		try {
			Movie opt=iMovieRepository.findById(id).orElseThrow(()-> new IllegalAccessException("Movie Not Found.."));
			iMovieRepository.deleteById(opt.getMid());
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return "MOvie Deleted With Id :: "+id;
	}
	
	
	@Override
	public String deleteMovie(Movie movie) {
		Optional<Movie> opt=iMovieRepository.findById(movie.getMid());
		if(opt.isPresent()) {
			iMovieRepository.delete(movie);
			return "Movie Deleted with The Id Of :: "+movie.getMid();
		}
		return "Movie Not Found....";
	}
	
	
	
	@Override
	public String deleteAllMovies() {
		long count=iMovieRepository.count();
		if(count!=0) {
			iMovieRepository.deleteAll();
			return "All The Movies Are Deleted....";
		}
		return "Movies Not Found To Delete...";
	}

}
