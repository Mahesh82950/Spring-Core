package com.nit.service;

import java.util.List;

import com.nit.entity.Movie;

public interface IMovieMngtService {
	public String registerMovie(Movie movie);
	public long countMovies();
	public boolean isMoviePresent(Integer mid);
	public Iterable<Movie> fetchAllMovies();
	public Iterable<Movie> fetchMoviesByIds(List<Integer> ids);
	public Movie fetById(Integer mid) throws IllegalAccessException;
	public String removeAllMoviesById(List<Integer> list);
	public String deleteMovieById(Integer id);
	public String deleteMovie(Movie movie);
	public String deleteAllMovies();

}
