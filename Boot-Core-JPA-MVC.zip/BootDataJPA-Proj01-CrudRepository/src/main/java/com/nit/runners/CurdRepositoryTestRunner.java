package com.nit.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.entity.Movie;
import com.nit.service.IMovieMngtService;

@Component
public class CurdRepositoryTestRunner implements CommandLineRunner {

	@Autowired
	private IMovieMngtService iMovieMngtService;
	
	@Override
	public void run(String... args) throws Exception {
		Movie movie=new Movie();
		movie.setMNAme("KaranArjun");
		movie.setYear(1998);
		movie.setRating(6.0f);
//
		try {
			System.out.println(iMovieMngtService.registerMovie(movie));
		}
		catch(Exception e) {
			e.printStackTrace();
		}
//		try {
//			System.out.println("Movie Count is :: "+iMovieMngtService.countMovies());
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		try {
//			System.out.println("Is Movie Present of ID 2 :: "+iMovieMngtService.isMoviePresent(2));
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
		try {
			Iterable<Movie> list=iMovieMngtService.fetchAllMovies();
			System.out.println("Using Enhanced For Loop...");
			for(Movie m:list) {
				System.out.println(m);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
//		System.out.println("======================================");
//		try {
//			Iterable<Movie> list=iMovieMngtService.fetchAllMovies();
//			System.out.println("Using ForEach with Lambda Expression...");
//			list.forEach((m)->System.out.println(m));
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println("======================================");
//		try {
//			Iterable<Movie> list=iMovieMngtService.fetchAllMovies();
//			System.out.println("Using Method Refrence...");
//			list.forEach(System.out::println);
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println("======================================");
//		try {
//			Iterable<Movie> list=iMovieMngtService.fetchAllMovies();
//			System.out.println("Using for Each and Stream Api + Method refrence...");
//			Arrays.asList(list).stream().forEach(System.out::println);
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
		
		
		
		
//		try {
//			List<Integer> list=new ArrayList(Arrays.asList(1,2,3,4));
//			Iterable<Movie> list1=iMovieMngtService.fetchMoviesByIds(list);
//			System.out.println(list1);
		
		
//			System.out.println("================================================");
//			System.out.println(iMovieMngtService.fetchMoviesByIds(List.of(2,5,4,3)));
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		try {
//			System.out.println(iMovieMngtService.fetById(7));
//			System.out.println("================================================");
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//			System.out.println(e.getMessage());
//		}

//		try {
//			System.out.println(iMovieMngtService.removeAllMoviesById(List.of(5,66)));
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
		
		
//		System.out.println(iMovieMngtService.deleteMovieById(25));
		
		
//		try {
//			System.out.println(iMovieMngtService.deleteMovie(movie));
//			
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
//		try {
//			System.out.println( iMovieMngtService.deleteAllMovies());
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
}
}
