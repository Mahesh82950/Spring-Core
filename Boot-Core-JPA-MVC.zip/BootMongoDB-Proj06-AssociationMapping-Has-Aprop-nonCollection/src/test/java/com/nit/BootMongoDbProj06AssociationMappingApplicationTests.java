package com.nit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootMongoDbProj06AssociationMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
