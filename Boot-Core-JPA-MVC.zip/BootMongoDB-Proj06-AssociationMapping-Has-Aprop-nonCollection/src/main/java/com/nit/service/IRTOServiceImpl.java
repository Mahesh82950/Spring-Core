package com.nit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.document.Driver;
import com.nit.document.DrivingLicence;
import com.nit.repository.IDriverRepo;
import com.nit.repository.IDrivingLicencerRepo;

@Service("rtoService")
public class IRTOServiceImpl implements IRTOService {

	@Autowired
	private IDriverRepo driverRepo;
	@Autowired
	private IDrivingLicencerRepo licencerRepo;
	@Override
	public String registerDriver(Driver driver) {
		
		return driverRepo.save(driver).getId()+" ID Driver is Registered...";
	}
	@Override
	public String registerDriverUSingLicence(DrivingLicence licence) {
		
		 return licencerRepo.save(licence).getDriver().getId()+" ID Driver is Registered...";
	}
	@Override
	public List<Driver> fetchAllDriverRecords() {
		
		return driverRepo.findAll();
	}
	@Override
	public List<DrivingLicence> fetchAllLicenceRecord() {
		return licencerRepo.findAll();
	}

}
