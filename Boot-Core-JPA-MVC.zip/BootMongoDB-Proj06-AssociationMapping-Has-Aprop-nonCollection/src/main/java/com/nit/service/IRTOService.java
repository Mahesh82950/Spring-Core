package com.nit.service;

import java.util.List;

import com.nit.document.Driver;
import com.nit.document.DrivingLicence;

public interface IRTOService {
	public String registerDriver(Driver driver);
	
	public String registerDriverUSingLicence(DrivingLicence licence);
	
	public List<Driver> fetchAllDriverRecords();
	public List<DrivingLicence> fetchAllLicenceRecord();

}
