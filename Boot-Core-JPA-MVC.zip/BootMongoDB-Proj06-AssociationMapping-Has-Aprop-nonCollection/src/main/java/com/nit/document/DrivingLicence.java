package com.nit.document;

import java.io.Serializable;
import java.time.LocalDate;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@RequiredArgsConstructor
@Document
public class DrivingLicence implements Serializable{
	@Id
	private String lid; 
	private String type;
	private LocalDate exp;
	
	private Driver driver;
	
	@Override
	public String toString() {
		return "DrivingLicence [lid=" + lid + ", type=" + type + ", exp=" + exp + "]";
	}
}
