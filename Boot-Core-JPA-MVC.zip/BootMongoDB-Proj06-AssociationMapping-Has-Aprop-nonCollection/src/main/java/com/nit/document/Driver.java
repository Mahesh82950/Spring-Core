package com.nit.document;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@RequiredArgsConstructor
@Document
public class Driver implements Serializable{

	@Id
	private Integer id;
	private String name;
	private Integer age;
	private String add;
	
	private DrivingLicence licence;

	@Override
	public String toString() {
		return "Driver [id=" + id + ", name=" + name + ", age=" + age + ", add=" + add + "]";
	}
	
}
