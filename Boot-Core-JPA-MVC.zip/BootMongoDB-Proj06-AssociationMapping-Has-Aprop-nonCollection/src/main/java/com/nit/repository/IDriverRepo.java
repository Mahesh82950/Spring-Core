package com.nit.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.nit.document.Driver;

public interface IDriverRepo extends MongoRepository<Driver, Integer>{

}
