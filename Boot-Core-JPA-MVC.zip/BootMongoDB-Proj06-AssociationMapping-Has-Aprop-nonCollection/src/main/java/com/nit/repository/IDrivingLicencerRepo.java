package com.nit.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.nit.document.Driver;
import com.nit.document.DrivingLicence;

public interface IDrivingLicencerRepo extends MongoRepository<DrivingLicence, String>{

}
