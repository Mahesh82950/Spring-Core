package com.nit.runner;

import java.time.LocalDate;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.document.Driver;
import com.nit.document.DrivingLicence;
import com.nit.service.IRTOService;

@Component
public class RTOTestRunner implements CommandLineRunner{

	@Autowired
	private IRTOService service;
	@Override
	public void run(String... args) throws Exception {
		
		Integer id=new Random().nextInt(10000000);
		DrivingLicence licence=new DrivingLicence();
		licence.setType("3-Wheeler");
		licence.setExp(LocalDate.now());
		Driver driver=new Driver();
		driver.setAdd("hydrabad");
		driver.setName("mahesh");
		driver.setAge(23);
		licence.setDriver(driver);
		driver.setId(id);
		
		
		System.out.println(service.registerDriverUSingLicence(licence));
		
		service.fetchAllDriverRecords().forEach(emp->{
			System.out.println(emp);
			System.out.println(emp.getLicence());
		});
		System.out.println("============================================");
		service.fetchAllLicenceRecord().forEach(emp->{
			System.out.println(emp);
			System.out.println(emp.getDriver());
		});
	}

}
