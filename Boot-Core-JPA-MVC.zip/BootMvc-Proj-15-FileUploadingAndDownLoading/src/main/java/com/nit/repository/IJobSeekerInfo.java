package com.nit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nit.entity.JobSeekerInfo;

public interface IJobSeekerInfo extends JpaRepository<JobSeekerInfo, Integer> {
	
	@Query("select photoPath from JobSeekerInfo where jid=:id")
	public String getPhotoPathById(Integer id);
	
	@Query("select resumePath from JobSeekerInfo where jid=:id")
	public String getResumePathById(Integer id);

}
