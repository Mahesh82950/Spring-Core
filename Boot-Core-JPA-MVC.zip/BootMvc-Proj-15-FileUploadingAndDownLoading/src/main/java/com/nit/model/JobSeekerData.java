package com.nit.model;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class JobSeekerData {

	private Integer jid;
	private String jname;
	private String addrs;
	private MultipartFile photo;
	private MultipartFile resume;
}
