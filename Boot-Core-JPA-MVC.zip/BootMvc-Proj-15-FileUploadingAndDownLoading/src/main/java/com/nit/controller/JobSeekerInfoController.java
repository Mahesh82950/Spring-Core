package com.nit.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.nit.entity.JobSeekerInfo;
import com.nit.model.JobSeekerData;
import com.nit.service.IJobSeekerInfoService;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class JobSeekerInfoController{
	
	@Autowired
	private IJobSeekerInfoService service;
	@GetMapping("/")
	public String getHome() {
		return "welcome";
	}
	
	@GetMapping("/register")
	public String getRegPage(@ModelAttribute("js") JobSeekerData data) {
		return"register";
	}
	@Autowired
	private Environment env;
	
	@PostMapping("/register")
	public String getRegPageData(@ModelAttribute("js") JobSeekerData data,HttpSession hs) throws Exception {
		String storePath=env.getRequiredProperty("upload.store");
		File file=new File(storePath);
		
		if(!file.exists()) {
			file.mkdir();
		}
		
		MultipartFile photoPath=data.getPhoto();
		MultipartFile resumePath=data.getResume();
		
		InputStream isPhoto=photoPath.getInputStream();
		InputStream isResume=resumePath.getInputStream();
		
		String resumeName=resumePath.getOriginalFilename();
		String photoName=photoPath.getOriginalFilename();
		
		OutputStream osresume=new FileOutputStream(file.getAbsoluteFile()+"\\"+resumeName);
		OutputStream osphoto=new FileOutputStream(file.getAbsoluteFile()+"\\"+photoName);
		
		IOUtils.copy(isPhoto,osphoto);
		IOUtils.copy(isResume,osresume);
		
		isPhoto.close();
		isResume.close();
		osphoto.close();
		osresume.close();
		
		JobSeekerInfo info=new JobSeekerInfo();
		info.setJname(data.getJname());
		info.setAddrs(data.getAddrs());
		info.setPhotoPath(file.getAbsoluteFile()+"\\"+photoName);
		info.setResumePath(file.getAbsoluteFile()+"\\"+resumeName);
		
		String msg=service.registerJobSeeker(info);
		hs.setAttribute("file1", resumeName);
		hs.setAttribute("file2", photoName);
		hs.setAttribute("resultMsg", msg);
		return"redirect:js_list";
	}
	
	@GetMapping("/js_list")
	public String getAllJobSeekers(Map<String,Object> map) {
		List<JobSeekerInfo> List=service.getAllJobSeekers();
		map.put("jsList", List);
		return "js_list";
	}
	
	@Autowired
	private ServletContext sc;
	@GetMapping("/download")
	public String getTheContent(@RequestParam("jid")Integer id,@RequestParam("type")String type,HttpServletResponse res) throws Exception {
		String filePath=null;
		if(type.equalsIgnoreCase("resume")) {
			filePath=service.getResumePathfromDB(id);
		}
		else {
			filePath=service.getPhotoPathfromDB(id);
		}
		System.out.println(filePath);
		
		File file=new File(filePath);
		res.setContentLengthLong(file.length());
		
		String mimeType=sc.getMimeType(filePath);
		mimeType=mimeType==null?"application/octet-stream":mimeType;
		res.setContentType(mimeType);
		InputStream is=new FileInputStream(file);
		OutputStream os=res.getOutputStream();
		
		res.setHeader("Content-Disposition", "attachment;filename= "+file.getName());
		
		IOUtils.copy(is,os);
		is.close();
		os.close();
		
		
		return null;
		
	}
	
	
	
	
	
}