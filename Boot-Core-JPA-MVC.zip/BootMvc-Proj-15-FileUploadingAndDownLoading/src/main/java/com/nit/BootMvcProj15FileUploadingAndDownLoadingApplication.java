package com.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@SpringBootApplication
public class BootMvcProj15FileUploadingAndDownLoadingApplication {

//	@Bean(name ="multipartResolver")
//	public CommonsMultipartResolver multipartResolver() {
//	    CommonsMultipartResolver resolver = new CommonsMultipartResolver();
//	    resolver.setMaxUploadSize(50 * 1024 * 1024); // 50 MB
//	    resolver.setMaxUploadSizePerFile(-1); // 50 MB
//	    return resolver;
//	}
	
	@Bean
	public ViewResolver createResolver() {
		InternalResourceViewResolver resolver=new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/pages/");
		resolver.setSuffix(".jsp");
		return resolver;
	}
	@Bean
    public StandardServletMultipartResolver multipartResolver() {
        return new StandardServletMultipartResolver();
    }
	public static void main(String[] args) {
		SpringApplication.run(BootMvcProj15FileUploadingAndDownLoadingApplication.class, args);
	}

}
