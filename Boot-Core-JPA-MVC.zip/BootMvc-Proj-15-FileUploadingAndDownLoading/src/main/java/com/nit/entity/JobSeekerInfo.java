package com.nit.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table
public class JobSeekerInfo implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer jid;
	@Column(length = 20)
	private String jname;
	@Column(length = 20)
	private String addrs;
	@Column(length = 200)
	private String photoPath;
	@Column(length = 200)
	private String resumePath;
}
