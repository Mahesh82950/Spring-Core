package com.nit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.entity.JobSeekerInfo;
import com.nit.repository.IJobSeekerInfo;

@Service("jobSeekerservice")
public class JobSeekerInfoServiceImpl implements IJobSeekerInfoService {

	@Autowired
	private IJobSeekerInfo repo;
	@Override
	public String registerJobSeeker(JobSeekerInfo info) {
		Integer id=repo.save(info).getJid();
		return id+" ID JobSeeker Registered...";
	}
	@Override
	public List<JobSeekerInfo> getAllJobSeekers() {
		return repo.findAll();
	}
	@Override
	public String getPhotoPathfromDB(Integer id) {
		
		return repo.getPhotoPathById(id);
	}
	@Override
	public String getResumePathfromDB(Integer id) {
		return repo.getResumePathById(id);
	}

}
