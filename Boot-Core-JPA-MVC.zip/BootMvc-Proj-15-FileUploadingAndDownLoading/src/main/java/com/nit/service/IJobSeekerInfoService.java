package com.nit.service;

import java.util.List;

import com.nit.entity.JobSeekerInfo;

public interface IJobSeekerInfoService {

	public String registerJobSeeker(JobSeekerInfo info);
	public List<JobSeekerInfo> getAllJobSeekers();
	
	public String getPhotoPathfromDB(Integer id);
	public String getResumePathfromDB(Integer id);
}
