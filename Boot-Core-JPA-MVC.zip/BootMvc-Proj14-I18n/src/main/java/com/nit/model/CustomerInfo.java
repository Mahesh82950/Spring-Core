package com.nit.model;

import lombok.Data;

@Data
public class CustomerInfo {

	private Integer cid;
	private String cname;
	private String addr;
	private Double billAmt;
}
