package com.nit.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.nit.model.CustomerInfo;

@Controller
public class CustomerI18nOperationController {
	
	@GetMapping("/")
	public String getHome() {
		return "home";
	}
	
	@GetMapping("/regist")
	public String showRegisterPage(@ModelAttribute("cust")CustomerInfo info,Map<String,Object> map) {
		return "register";
	}
	
	@PostMapping("/regist")
	public String getRegisterPage(@ModelAttribute("cust")CustomerInfo info,Map<String,Object> map) {
		map.put("custInfo", info);
		System.out.println(info);
		return "get_register";
	}
}
