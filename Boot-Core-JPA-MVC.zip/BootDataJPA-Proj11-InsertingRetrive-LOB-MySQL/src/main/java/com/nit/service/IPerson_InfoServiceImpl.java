package com.nit.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.dao.IPerson_InfoDao;
import com.nit.entity.Person_Info;
@Service("perService")
public class IPerson_InfoServiceImpl implements IPerson_InfoService {

	@Autowired
	private IPerson_InfoDao dao;
	
	@Override
	public String registerPerson(Person_Info info) {
		return dao.save(info).getPid()+" ID Person is Registered...";
		
	}

	@Override
	public Person_Info fetchPersonInfo(Integer id) {
		Optional<Person_Info> opt=dao.findById(id);
		if(opt.isPresent()) {
			return opt.get();
		}
		return null;
	}

	

}
