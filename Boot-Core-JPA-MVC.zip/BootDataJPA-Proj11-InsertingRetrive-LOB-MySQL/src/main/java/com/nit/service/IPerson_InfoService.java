package com.nit.service;

import java.util.List;

import com.nit.dao.IPerson_InfoDao;
import com.nit.entity.Person_Info;

public interface IPerson_InfoService{
	public  String registerPerson(Person_Info info);
	public Person_Info fetchPersonInfo(Integer id);

}
