package com.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj11InsertingLobMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj11InsertingLobMySqlApplication.class, args);
	}

}
