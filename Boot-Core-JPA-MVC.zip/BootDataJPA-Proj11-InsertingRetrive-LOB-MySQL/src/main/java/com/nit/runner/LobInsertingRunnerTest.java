package com.nit.runner;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.Writer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.entity.Person_Info;
import com.nit.service.IPerson_InfoService;

@Component
public class LobInsertingRunnerTest implements CommandLineRunner {

	@Autowired
	private IPerson_InfoService service;
	@Override
	public void run(String... args) throws Exception {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter Person NAme :: ");
//		String name=sc.next();
//		System.out.println("Enter person MarriedStatus :: isMArried :: ?");
//		Boolean isMarried=sc.nextBoolean();
//		
//		System.out.println("Enter The Photo Path :: ");
//		String photoPath=sc.next();
//		System.out.println("Enter The Resume Path :: ");
//		String resumePath=sc.next();
//		
//		InputStream is=new FileInputStream(photoPath);
//		byte[] photo=new byte[is.available()];
//		photo=is.readAllBytes();
//		
//		Reader reader=new FileReader(resumePath);
//		File file=new File(resumePath);
//		char[] resume=new char[(int) file.length()];
//		reader.read(resume);
//		
//		try {
//			Person_Info info=new Person_Info(-1,name,LocalDateTime.of(2024, 10, 20, 02, 45),isMarried,photo,resume);
//			System.out.println(service.registerPerson(info));
//			}catch (Exception e) {
//				e.printStackTrace();
//			}
		try {
		Person_Info info=service.fetchPersonInfo(1);
		if(info!=null) {
			System.out.println(info.getPname()+" "+info.getPid()+" "+info.getLdt());
			byte[] photo1=info.getPhoto();
			OutputStream outputStream=new FileOutputStream("retrive_photo.gif");
			outputStream.write(photo1);
			outputStream.flush();
			outputStream.close();
			System.out.println("Photo Retrived From DB...");
			
			char[] resume=info.getResume();
			Writer writer=new FileWriter("retrive_Resume.txt");
			writer.write(resume);
			writer.flush();
			writer.close();
			System.out.println("Resume Retrived From DB...");
			
		}
		else {
			System.out.println("Record Not Found...");
		}

	}catch (Exception e) {
		e.printStackTrace();
	}
	}
	
	

}
