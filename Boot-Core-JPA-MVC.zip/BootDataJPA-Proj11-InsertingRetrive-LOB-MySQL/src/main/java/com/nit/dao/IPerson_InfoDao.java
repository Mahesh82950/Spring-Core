package com.nit.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nit.entity.Person_Info;

public interface IPerson_InfoDao extends JpaRepository<Person_Info, Integer>{

	
}
