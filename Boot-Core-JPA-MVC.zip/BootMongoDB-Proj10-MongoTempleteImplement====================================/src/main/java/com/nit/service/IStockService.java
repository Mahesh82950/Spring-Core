package com.nit.service;

import java.util.List;

import com.nit.document.StockDetails;

public interface IStockService {
	public String registerStock(StockDetails stock);

	public long registerStocks(List<StockDetails> stocks);
	
	public List<StockDetails> fetchStockByCriteria(String criteria);
	
	public List<StockDetails> fetchStockBypriceRange(double startPrice,double endPrice);
	
	public String updateStockById(StockDetails details);
	
	public StockDetails findById(Integer id);
	
	public String fetchAndUpdatetockBystockId(Integer id,Double newPrice,String exchange);
	
	public String modifyExchangeByPriceRange(Double startPrice,Double endPrice,String exchange);
	
	public String registerOrUpdateStockByStockName(String stockName,double newPrice,String newExchange);
	
	public String fetchAndRemoveByStockNAme(String stockName);


	
}
