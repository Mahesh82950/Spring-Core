package com.nit.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import com.nit.document.StockDetails;

@Service("stockService")
public class StockrServiceImpl implements IStockService {

	@Autowired
	private MongoTemplate template;

	@Override
	public String registerStock(StockDetails stock) {
		Integer id=template.insert(stock).getId();
		return id+" ID Stock Is Registered...";
	}

	@Override
	public long registerStocks(List<StockDetails> stocks) {
		return template.insertAll(stocks).size();
	}

	@Override
	public List<StockDetails> fetchStockByCriteria(String criteria) {
	Query query=new Query();
	query.addCriteria(Criteria.where("exchange").is(criteria));
	List<StockDetails> list=template.find(query, StockDetails.class);
		return list;
	}

	@Override
	public List<StockDetails> fetchStockBypriceRange(double startPrice, double endPrice) {
		Query query=new Query();
		query.addCriteria(Criteria.where("price").gte(startPrice).lte(endPrice));
		List<StockDetails> list=template.find(query, StockDetails.class);
		return list;
	}

	@Override
	public String updateStockById(StockDetails details) {
		return template.save(details).getId()+" Id Stock is Updated...";
		
	}
	@Override
	public StockDetails findById(Integer id) {
		
		return template.findById(id, StockDetails.class);
	}
	@Override
	public String fetchAndUpdatetockBystockId(Integer id, Double newPrice, String newExchange) {
		Query query=new Query();
		query.addCriteria(Criteria.where("id").is(id));
		Update update=new Update();
		update.set("price", newPrice);
		update.set("exchange",newExchange);
		StockDetails details=template.findAndModify(query, update, StockDetails.class);
		return details==null?"Stock Not Found...":"Stock Updated SuccessFully...";
		
	}
	@Override
	public String modifyExchangeByPriceRange(Double startPrice, Double endPrice, String exchange) {
		Query query=new Query();
		query.addCriteria(Criteria.where("price").gt(startPrice).andOperator(Criteria.where("price").lt(endPrice)));
		Update update=new Update();
		update.set("exchange", exchange);
		UpdateResult result=template.updateMulti(query, update,StockDetails.class);
		return result==null?"Stock Not Found...":"Stocks Updated....";
	}
	
	@Override
	public String registerOrUpdateStockByStockName(String stockName, double newPrice, String newExchange) {
		Query query=new Query();
		query.addCriteria(Criteria.where("name").is(stockName));
		Update update=new Update();
		update.set("exchange", newExchange);
		update.set("price", newPrice);
		update.setOnInsert("name", stockName);
		update.setOnInsert("id", new Random().nextInt(10000));
		UpdateResult result=template.upsert(query, update,StockDetails.class);
		
		return result.getModifiedCount()+" Number of Record Are Effected....";


	}

	@Override
	public String fetchAndRemoveByStockNAme(String stockName) {
		Query query=new Query();
		query.addCriteria(Criteria.where("name").is(stockName));
		StockDetails result=template.findAndRemove(query,StockDetails.class);
		return result==null?"Stock Not Found...":"stock Deleted...";
	}

	
	
	
}
