package com.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.service.IStockService;

@Component
public class StockrTestRunner implements CommandLineRunner {

	@Autowired
	private IStockService service;
	@Override
	public void run(String... args) throws Exception {
		
//		StockDetails stock=new StockDetails(new Random().nextInt(100000), "IRB INFRA", "NSE", 47.150);
//		System.out.println(service.registerStock(stock));
		
//		StockDetails stock1=new StockDetails(new Random().nextInt(100000), "GTL INFRA", "NSE",300.0);
//
//		StockDetails stock2=new StockDetails(new Random().nextInt(100000), "NEXON INFRA", "BSE", 472.50);
//
//		StockDetails stock3=new StockDetails(new Random().nextInt(100000), "MRF", "NSE", 147.250);
//		
//		System.out.println("Number of Stocks Registerd are :: "+service.registerStocks(List.of(stock1,stock2,stock3)));

		service.fetchStockByCriteria("NYSE").forEach(System.out::println);
//		System.out.println("=========================================");
		
//		service.fetchStockBypriceRange(100d,500d).forEach(System.out::println);
//		StockDetails stock=new StockDetails(75030, "IRB INFRA", "NSE", 48.150);
//		System.out.println(service.updateStockById(stock));

//		System.out.println(service.findById(75030));
		
	//	System.out.println(service.fetchAndUpdatetockBystockId(75030, 70.0, "NYSE"));
		
	//	System.out.println(service.modifyExchangeByPriceRange(100d, 400d, "CSE"));

//		System.out.println(service.registerOrUpdateStockByStockName("BUGGATIZUN", 30000.2, "NYSE"));
//		
//		System.out.println(service.fetchAndRemoveByStockNAme("BUGGATIZUN"));
	}

}
