package com.nit.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.nit.model.Employee;
import com.nit.repo.IEmployeeRepo;

@Service("empServie")
public class EmployeeReportServiceImpl implements IEmoployeeReportService {

	@Autowired
	private IEmployeeRepo repo;
	

	@Override
	public String addEmployee(Employee emp) {
		Integer id=repo.save(emp).getEid();
		return "ID No :: "+id+" Employee Registered SuccessFully..";
	}

	@Override
	public Employee editEmployee(Integer id) {
		Employee emp=repo.findById(id).get();
		return emp;
	}

	@Override
	public String editEmployee(Employee emp) {
		Integer id=repo.save(emp).getEid();
		return "Employee Updated of ID :: "+id;
	}

	@Override
	public String deletEmployee(Integer id) {
		repo.deleteById(id);
		return id+" :: ID Employee Deleted...";
	}

	@Override
	public Page<Employee> getAllEmployee(Pageable pageable) {
		Page<Employee> page=repo.findAll(pageable);
		return page;
	}

	@Override
	public Set<String> getAllCountry() {
		Locale[] locale=Locale.getAvailableLocales();
		Set<String> set=new TreeSet<String>();
		for(Locale l:locale) {
			if(l!=null) {
				set.add(l.getDisplayCountry());
			}
		}
		return set;
	}
	
	@Autowired
	private Environment env;

	@Override
	public List<String> getstatebycountry(String country) {
		String str=env.getRequiredProperty(country);
		System.out.println(str);
		List<String> list=Arrays.asList(str.split(","));
		Collections.sort(list);
		return list;
	}

}
