package com.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.document.Cricketer;
import com.nit.service.ICricketerService;

@Component
public class CricketerTestRunner implements CommandLineRunner {

	@Autowired
	private ICricketerService service;
	@Override
	public void run(String... args) throws Exception {

//		service.getCricketerByRegExpres("^r").forEach(System.out::println);
//		service.getCricketerByRegExpres("t$").forEach(System.out::println);
//		service.getCricketerByRegExpres("a").forEach(System.out::println);

		service.getCricketerSortByName().forEach(System.out::println);
	//	System.out.println("Total count of Criketer Between avrage :: "+service.getTotalCricketer(30.0, 55.0));

		System.out.println("Total count of Criketer Deleted :: "+service.deleteCricketerByCountry());

	}

}
