package com.nit.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nit.document.Cricketer;

import lombok.val;

public interface ICricketerRepo extends MongoRepository<Cricketer, String> {

	@Query(value = "{name:{$regex:?0}}")
	public List<Cricketer> getCricketerByRegExpres(String expression);
	
	@Query(value = "{}",sort ="{name:1}")
	public List<Cricketer> getCricketerSortByName();
	
	@Query(value = "{avrg:{$gte:?0,$lte:?1}}",count = true)
	public int getTotalCricketer(Double minAvg,Double maxAvg);
	
	@Query(value="{country:null}",delete = true)
	public int deleteCricketerByCountry();

}
