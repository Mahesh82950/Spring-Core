package com.nit.service;

import java.util.List;

import com.nit.document.Cricketer;

public interface ICricketerService {

	public List<Cricketer> getCricketerByRegExpres(String expression);

	public List<Cricketer> getCricketerSortByName();

	public int getTotalCricketer(Double minAvg,Double maxAvg);

	public int deleteCricketerByCountry();


	
}
