package com.nit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.nit.document.Cricketer;
import com.nit.repository.ICricketerRepo;

@Service("crktService")
public class CricketerServiceImpl implements ICricketerService {

	@Autowired
	private ICricketerRepo repo;

	@Override
	public List<Cricketer> getCricketerByRegExpres(String expression) {
		return repo.getCricketerByRegExpres(expression);
	}

	@Override
	public List<Cricketer> getCricketerSortByName() {
		// TODO Auto-generated method stub
		return repo.getCricketerSortByName();
	}

	@Override
	public int getTotalCricketer(Double minAvg,Double maxAvg) {
		
		return repo.getTotalCricketer(maxAvg, maxAvg);
	}

	@Override
	public int deleteCricketerByCountry() {
		// TODO Auto-generated method stub
		return repo.deleteCricketerByCountry();
	}

	
	
	
}
