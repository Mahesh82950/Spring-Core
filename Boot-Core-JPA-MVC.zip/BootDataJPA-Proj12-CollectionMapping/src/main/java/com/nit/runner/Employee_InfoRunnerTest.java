package com.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.service.IEmployee_InfoService;

@Component
public class Employee_InfoRunnerTest implements CommandLineRunner {

	@Autowired
	private IEmployee_InfoService service;
	@Override
	public void run(String... args) throws Exception {
		
//		Employee_Info info=new Employee_Info(101, "Mahesh", List.of("Vikas,Marot"), Set.of(99999999L,888888888L), Map.of("Adhar","52872175","Voter_Id","LJH54646"));
//		System.out.println(service.registerEmployee(info));
//		
		System.out.println("====================================================");
		service.fetchAllEmployee().forEach(System.out::println);
	}

}
