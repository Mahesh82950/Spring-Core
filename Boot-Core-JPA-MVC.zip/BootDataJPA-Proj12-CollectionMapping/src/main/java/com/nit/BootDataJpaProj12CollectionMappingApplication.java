package com.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj12CollectionMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj12CollectionMappingApplication.class, args);
	}

}
