package com.nit.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nit.entity.Employee_Info;

public interface IEmployee_InfoDao extends JpaRepository<Employee_Info, Integer> {

}
