package com.nit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.dao.IEmployee_InfoDao;
import com.nit.entity.Employee_Info;

@Service("empService")
public class IEmployee_InfoServiceImpl implements IEmployee_InfoService {
@Autowired
	private IEmployee_InfoDao dao;
	@Override
	public String registerEmployee(Employee_Info info) {
		return dao.save(info).getEid()+" ID Employee Registered...";
	}

	@Override
	public List<Employee_Info> fetchAllEmployee() {
		return dao.findAll();
	}

}
