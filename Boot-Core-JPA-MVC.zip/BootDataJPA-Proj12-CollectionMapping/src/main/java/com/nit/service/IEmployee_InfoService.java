package com.nit.service;

import java.util.List;

import com.nit.entity.Employee_Info;

public interface IEmployee_InfoService {

	public String registerEmployee(Employee_Info info);
	public List<Employee_Info> fetchAllEmployee();
}
