package com.nit.runner;

import java.util.UUID;

import javax.crypto.Cipher;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.document.Cricketer;
import com.nit.service.ICricketerService;

@Component
public class CricketerTestRunner implements CommandLineRunner {

	@Autowired
	private ICricketerService service;
	@Override
	public void run(String... args) throws Exception {
		System.out.println("====================insert(entity)==========================");
		Cricketer cricketer=new Cricketer();
		String id=UUID.randomUUID().toString();
		System.out.println(id);
		cricketer.setId(id);
		cricketer.setJNumber(1);
		cricketer.setName("rahul");
		cricketer.setAvrg(50D);
		cricketer.setNickname("klassy");
		cricketer.setCenturies(20);
		cricketer.setCountry("India");
//		Cricketer cricketer=new Cricketer();
//		cricketer.setJNumber(0);
//		cricketer.setName("rakesh");
//		cricketer.setAvrg(52d);
////		cricketer.setNickname("carry");
//		cricketer.setCenturies(10);
////		cricketer.setCountry("India");
		try {
			System.out.println(service.registerCricketer(cricketer));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
//		System.out.println("====================FindAll(Example,sort)==========================");
//		Cricketer cricketer=new Cricketer();
//		cricketer.setAvrg(52.0);
//		try {
//			service.getCricketerByCricketer(cricketer, true,"name").forEach(System.out::println);
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println("====================FindAll(Example)==========================");
//		Cricketer cricketer=new Cricketer();
//		cricketer.setAvrg(52.0);
//		try {
//			service.getCricketerByCricketer(cricketer).forEach(System.out::println);
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println("====================FindAll()==========================");
//		try {
//			service.getAllCricketer().forEach(System.out::println);
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println("====================deleteById()==========================");
//		try {
//			System.out.println(service.bancricketer("6735a00d12a789320d4eaa4"));
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
		
//		System.out.println("====================UpdateById()==========================");
//		try {
//			System.out.println(service.modifyCricketersAvrg("6734e8a2eed2134c5a5113ee", 55d));
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
	}

}
