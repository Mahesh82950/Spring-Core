package com.nit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.nit.entity.Movie;

@Transactional
public interface IMovieRepository extends JpaRepository<Movie,Integer> {

	@Query("update Movie set rating=:newRating where mid=:id")
	@Modifying
	public int updateRatingById(float newRating,int id);
	
	@Query("delete from Movie where year=:year1")
	@Modifying
	public int deleteMovieByYear(int year1);
//	
//	
	@Query(value="insert into movie values(?,?,?,?)",nativeQuery = true)
	@Modifying
	public int registerMovie(int id,String name,float rating,int year);
	
	@Query(value="create table Temp01(col1 varchar(10))",nativeQuery = true)
	@Modifying
	public int createTable();
	
	@Query(value="select sysdate()",nativeQuery = true)
	public String fetchDate();
}
