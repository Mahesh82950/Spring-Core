package com.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.repository.IMovieRepository;

@Component
public class FinderMothodTestRnner implements CommandLineRunner {

	@Autowired
	private IMovieRepository iMovieMngtService;

	@Override
	public void run(String... args) throws Exception {

		System.out.println("===============================================");
//
//		System.out.println("No of Movies Updated Are :: "+iMovieMngtService.updateRatingById(5.7f, 24));
//		
//		System.out.println("=============================================================");
//
//		System.out.println("No of Movies Deleted Are :: "+iMovieMngtService.deleteMovieByYear(2012));
//		
//		System.out.println("=============================================================");
//
//		System.out.println("No of Movies Inserted Are :: "+iMovieMngtService.registerMovie(11, "natwarlal", 8.0f, 2000));

		System.out.println("=======================================================");
//		System.out.println(iMovieMngtService.createTable()>0?"table Not Created":"Table Created SuccessFully");
	
		System.out.println("=======================================================");
		System.out.println("Todays Date is :: "+iMovieMngtService.fetchDate());
	
	}
	
}
