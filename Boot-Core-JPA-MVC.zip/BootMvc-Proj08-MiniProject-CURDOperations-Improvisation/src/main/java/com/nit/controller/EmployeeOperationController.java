package com.nit.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nit.model.Employee;
import com.nit.service.IEmoployeeReportService;

import ch.qos.logback.core.joran.util.beans.BeanUtil;
import jakarta.servlet.http.HttpSession;

@Controller
public class EmployeeOperationController {

	@Autowired
	private IEmoployeeReportService service;
	
	@GetMapping("/")
	public String showHome() {
		return "home";
	}
	
	@GetMapping("report")
	public String getEmpReport(Map<String,Object> map) {
		List<Employee> list=service.getAllEmployee();
		map.put("empData", list);
		return "show_report";
	}
	
	@GetMapping("/add")
	public String showAddEmpForm(@ModelAttribute("emp") Employee emp) {
		emp.setJob("Clerk");
		return "employee_register";
	}
//	@PostMapping("/add")
//	public String AddEmpForm(Map<String,Object> map,@ModelAttribute("emp") Employee emp) {
//		String result=service.addEmployee(emp);
//		map.put("resMsg", result);
//		return "redirect:report";//using this:: resMsg will not shows because the scope is request for every model class obj
//	}
	
	@PostMapping("/add")
	public String AddEmpForm(HttpSession ses,@ModelAttribute("emp") Employee emp) {
		String result=service.addEmployee(emp);
		ses.setAttribute("resMsg", result);
		return "redirect:report"; //using this:: resMsg will be shows until you close browser(best)
	}
	
	
//	@PostMapping("/add")
//	public String AddEmpForm(RedirectAttributes red,@ModelAttribute("emp") Employee emp) {
//		String result=service.addEmployee(emp);
//		red.addFlashAttribute("resMsg", result);
//		return "redirect:report"; //using this:: resMsg will be shows until you refresh it second time after than clears the msg..
//	}
	
	@GetMapping("/edit")
	public String showEditEmployeeForm(@RequestParam("eno") int no,@ModelAttribute("emp") Employee emp) {
		Employee employee=service.editEmployee(no);
		BeanUtils.copyProperties(employee, emp);
		return "edit_emp";
	}
	@PostMapping("/edit")
	public String editEmployeeForm(@ModelAttribute("emp") Employee emp,Map<String,Object> map) {
		String result=service.editEmployee(emp);
        map.put("resMsg", result);
        
		return "redirect:report";
	}
	
	
	@GetMapping("/delete")
	public String deleteEmployee(@RequestParam("eno") int no,Map<String,Object> map) {
	String result=service.deletEmployee(no);
	  map.put("resMsg", result);
    
	return "redirect:report";
}
}
