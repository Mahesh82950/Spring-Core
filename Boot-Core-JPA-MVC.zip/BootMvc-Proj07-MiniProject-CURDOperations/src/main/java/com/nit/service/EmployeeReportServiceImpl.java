package com.nit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.model.Employee;
import com.nit.repo.IEmployeeRepo;

@Service("empServie")
public class EmployeeReportServiceImpl implements IEmoployeeReportService {

	@Autowired
	private IEmployeeRepo repo;
	
	@Override
	public List<Employee> getAllEmployee() {
		return repo.findAll();
	}

	@Override
	public String addEmployee(Employee emp) {
		Integer id=repo.save(emp).getEid();
		return "ID No :: "+id+" Employee Registered SuccessFully..";
	}

	@Override
	public Employee editEmployee(Integer id) {
		Employee emp=repo.findById(id).get();
		return emp;
	}

	@Override
	public String editEmployee(Employee emp) {
		Integer id=repo.save(emp).getEid();
		return "Employee Updated of ID :: "+id;
	}

	@Override
	public String deletEmployee(Integer id) {
		repo.deleteById(id);
		return id+" :: ID Employee Deleted...";
	}

}
