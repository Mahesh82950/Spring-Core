package com.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMvcProj06MiniProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMvcProj06MiniProjApplication.class, args);
	}

}
