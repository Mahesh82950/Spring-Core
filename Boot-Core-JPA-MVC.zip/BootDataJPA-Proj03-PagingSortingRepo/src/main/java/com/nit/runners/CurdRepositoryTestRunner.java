package com.nit.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import com.nit.entity.Movie;
import com.nit.service.IMovieMngtService;

@Component
public class CurdRepositoryTestRunner implements CommandLineRunner {

	@Autowired
	private IMovieMngtService iMovieMngtService;
	@Override
	public void run(String... args) throws Exception {
//		try {
//		Iterable<Movie> it=iMovieMngtService.findMovieByOrder(true, "mNAme");
//		it.forEach(System.out::println);
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
		try {
			Page<Movie> page=iMovieMngtService.displayInfo(0, 3, false, "mNAme");
			System.out.println("Page Number :: "+page.getNumber());
			System.out.println("PAge Size :: "+page.getSize());
			System.out.println("Is First Page ::"+page.isFirst());
			List<Movie> list=page.getContent();
			list.forEach(System.out::println);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
}
}
