package com.nit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.nit.entity.Movie;
import com.nit.repository.IMovieRepository;

@Service("imovieService")
public class IMovieMngServiceImpl implements IMovieMngtService {

	@Autowired
	private IMovieRepository  iMovieRepository;

	@Override
	public Iterable<Movie> findMovieByOrder(Boolean asc, String... properties) {
		Sort sort=Sort.by(asc?Direction.ASC:Direction.DESC,properties);
		
		return iMovieRepository.findAll(sort);
	}

	@Override
	public Page<Movie> displayInfo(int pageNo, int pageSize, Boolean asc, String... properties) {
		PageRequest pageable=PageRequest.of(pageNo, pageSize,Sort.by(asc?Direction.ASC:Direction.DESC,properties));
		
		return iMovieRepository.findAll(pageable);
	}
	

}
