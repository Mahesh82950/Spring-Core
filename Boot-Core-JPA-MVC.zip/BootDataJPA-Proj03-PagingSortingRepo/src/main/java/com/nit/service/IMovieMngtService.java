package com.nit.service;

import org.springframework.data.domain.Page;

import com.nit.entity.Movie;

public interface IMovieMngtService {
	public Iterable<Movie> findMovieByOrder(Boolean asc,String...properties);
	public Page<Movie> displayInfo(int pageNo,int pageSize,Boolean asc,String ...properties);

}
