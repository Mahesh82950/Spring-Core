package com.nit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootMvcProj02WishMessageGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
