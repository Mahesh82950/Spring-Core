package com.nit.controller;

import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nit.service.IWishmessageGeneratorService;

@Controller
public class WishMessageGeneratorController {

	@Autowired
	private IWishmessageGeneratorService service;
	
	@RequestMapping("/")
	public String showHomePage() {
		return "welcome";
	}
	
//	@RequestMapping("/wish")
//	public ModelAndView getMessage() {
//		ModelAndView mav=new ModelAndView();
//		
//		String msg=service.generateWish();
//		mav.addObject("message",msg);
//		mav.addObject("sysdate",new Date());
//		mav.setViewName("ResultView");
//		
//		return mav; 
//	}
	
//	@RequestMapping("/wish")
//	public String getMessage(Model model) {
//		String  msg=service.generateWish();
//		
//		model.addAttribute("message", msg);
//		model.addAttribute("sysdate", new Date());
//		return "ResultView";    //->>>>>>   if no logical view name is returned then it will take
	                            //            request path name(wish) as logical view name;
//	}
	
//	@RequestMapping("/wish")
//	public String getMessage(ModelMap model) {
//		String  msg=service.generateWish();
//		
//		model.addAttribute("message", msg);
//		model.addAttribute("sysdate", new Date());
//		return "ResultView";
//	}
	
//	@RequestMapping("/wish")
//	public String getMessage(Map<String,Object> map) {
//		System.out.println(map.getClass());
//		String  msg=service.generateWish();
//		
//		map.put("message", msg);
//		map.put("sysdate", new Date());
//		return "ResultView";
//	}
}
