package com.nit.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

@Service
public class WishMessageGeneratorServiceimpl implements IWishmessageGeneratorService {

	 LocalDateTime ldt=LocalDateTime.now();
	@Override
	public String generateWish(){
		int hours=ldt.getHour();
		if(hours>12&&hours<=16) {
			return "Good AfterNoon";
		}else if(hours>16&&hours<=20) {
			return "Good Evening";
		}else if(hours>20&&hours<=24) {
			return "Good AfterNoon";
		}else
		return "Goood Morning";
	}

}
