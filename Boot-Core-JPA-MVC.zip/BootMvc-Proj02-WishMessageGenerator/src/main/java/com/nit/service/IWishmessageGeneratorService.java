package com.nit.service;

public interface IWishmessageGeneratorService {

	public String generateWish();
}
