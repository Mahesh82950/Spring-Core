package com.nit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootMvcProj03DataRenderingApplicationTests {

	@Test
	void contextLoads() {
	}

}
