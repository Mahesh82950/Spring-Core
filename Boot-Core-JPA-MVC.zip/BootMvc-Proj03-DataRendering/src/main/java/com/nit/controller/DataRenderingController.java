package com.nit.controller;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.nit.model.Product;

@Controller
public class DataRenderingController {
	
	@GetMapping("/")
	public String getmessage() {
		return "welcome";
	}

//	@GetMapping("/report")
//	public String getReport(Map<String,Object> map) {
//		
//		map.put("name", "Mahesh");
//		map.put("age", 22);
//		map.put("add", "Hydrabad");
//		return "report";
//	}
//	@GetMapping("/report")
//	public String getReport(Map<String,Object>map) {
//		map.put("favColors",new String[] {"Cyan","Black","Saffron"});
//		map.put("contacts", Set.of(88888888L,7777777L,6666666L));
//		map.put("nickNames",List.of("raja","maharaj","king"));
//		map.put("idDetails",Map.of("adahar",585897979L,"pan","PBL6989G","voterId",56787899L));
//		return "report";
//	}
	
//	@GetMapping("/report")
//	public String getReport(Map<String,Object>map) {
//		Product product=new Product(101, "Table", 2000, 3);
//		map.put("prod",product);
//		return "report";
//	}
	
	@GetMapping("/report")
	public String getReport(Map<String,Object>map) {
		Product product=new Product(101, "Table", 2000, 3);
		Product product1=new Product(102, "book", 2000, 8);
		Product product2=new Product(103, "pen", 20, 13);
		map.put("prod",List.of(product,product1,product2));
		return "report";
	}
}
