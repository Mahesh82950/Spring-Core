package com.nit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.document.Cricketer;
import com.nit.repository.ICricketerRepo;

@Service("crktService")
public class CricketerServiceImpl implements ICricketerService {

	@Autowired
	private ICricketerRepo repo;

	@Override
	public List<Cricketer> findBycountry(String country) {
		
		return repo.findBycountryOrderByJNumberAsc(country);
	}

	@Override
	public Cricketer findByJersey(Integer jersey) {
		
		return repo.findByJNumber(jersey);
	}

	@Override
	public List<Cricketer> findByavrgGreaterThan(Double avrg) {
		
		return repo.findByAvrgGreaterThan(avrg);
	}
	
}
