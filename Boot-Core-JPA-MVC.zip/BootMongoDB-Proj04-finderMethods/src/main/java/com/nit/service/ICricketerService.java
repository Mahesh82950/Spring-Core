package com.nit.service;

import java.util.List;

import com.nit.document.Cricketer;

public interface ICricketerService {

	public List<Cricketer> findBycountry(String country);
	
	public Cricketer findByJersey(Integer jersey);
	
	public List<Cricketer> findByavrgGreaterThan(Double avrg);
}
