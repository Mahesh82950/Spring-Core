package com.nit.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.nit.document.Cricketer;

public interface ICricketerRepo extends MongoRepository<Cricketer, String> {

	public List<Cricketer> findBycountryOrderByJNumberAsc(String country);
	
	public Cricketer findByJNumber(Integer jersey);
	
	public List<Cricketer> findByAvrgGreaterThan(Double avrg);
	}
