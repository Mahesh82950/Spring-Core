package com.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.service.ICricketerService;

@Component
public class CricketerTestRunner implements CommandLineRunner {

	@Autowired
	private ICricketerService service;
	@Override
	public void run(String... args) throws Exception {
		try {
			service.findBycountry("India").forEach(System.out::println);
			
			System.out.println("====================================================");
			System.out.println(service.findByJersey(18));
			
			System.out.println("=========================================================");
			service.findByavrgGreaterThan(52.0).forEach(System.out::println);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
