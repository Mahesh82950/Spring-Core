package com.nit.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nit.entity.Person;
import com.nit.entity.PhoneNumber;

public interface IPhoneNumberDao extends JpaRepository<PhoneNumber, Integer> {

}
