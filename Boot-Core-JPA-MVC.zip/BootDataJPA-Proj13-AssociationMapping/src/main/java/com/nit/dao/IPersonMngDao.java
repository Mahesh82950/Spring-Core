package com.nit.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nit.entity.Person;

public interface IPersonMngDao extends JpaRepository<Person, Integer> {

}
