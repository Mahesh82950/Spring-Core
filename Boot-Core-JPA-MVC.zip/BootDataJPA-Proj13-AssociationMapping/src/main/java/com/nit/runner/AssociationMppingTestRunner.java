package com.nit.runner;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.entity.Person;
import com.nit.entity.PhoneNumber;
import com.nit.service.IPersonMngService;

@Component
public class AssociationMppingTestRunner implements CommandLineRunner {
@Autowired
private IPersonMngService service;
	@Override
	public void run(String... args) throws Exception {

		PhoneNumber number=new PhoneNumber();
		number.setPhoneNumber(666666666L);
		number.setNumberType("Residency");
		number.setProvider("Vi");
		PhoneNumber number1=new PhoneNumber();
		number1.setPhoneNumber(555555555L);
		number1.setNumberType("Office");
		number1.setProvider("Bsnl");
		Person person=new Person();
		person.setPname("Natraj");
		person.setPaddr("Vizag");
		person.setPhNumber(Set.of(number,number1));
		try {
		//System.out.println(service.registerPerson(person));
		//	service.getPersonDetailsById(2);
		//	System.out.println(service.deletePersonById(2));
			
			List<Person> list=service.getAllRecords();
			list.forEach(emp->{
				System.out.println(emp);
				System.out.println(emp.getPhNumber());
			});
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
