package com.nit.service;

import java.util.List;

import com.nit.entity.Person;

public interface IPersonMngService {
public String registerPerson(Person person);

public void getPersonDetailsById(Integer id);

public String deletePersonById(Integer id);

public List<Person> getAllRecords();
}
