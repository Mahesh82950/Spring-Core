package com.nit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.dao.IPersonMngDao;
import com.nit.entity.Person;

@Service("empService")
public class IPersonMngImpl implements IPersonMngService {

	@Autowired
	private IPersonMngDao dao;
	@Override
	public String registerPerson(Person person) {
		
		return dao.save(person).getPid()+" ID Person Is Saved...";
	}
	@Override
	public void getPersonDetailsById(Integer id) {
		Optional<Person> opt=dao.findById(id);
		if(opt.isPresent()) {
			System.out.println(opt.get());
			System.out.println(opt.get().getPhNumber());
		}
		else {
			System.out.println("Person With given Id NOt Found....");
		}
		
	}
	@Override
	public String deletePersonById(Integer id) {
		Optional<Person> opt=dao.findById(id);
		if(opt.isPresent()) {
			dao.deleteById(id);
			return opt.get().getPid()+" Id Person Is Deleted...";
		}
		return "Given Id Person Is Not Found To Deleted...";
	}
	@Override
	public List<Person> getAllRecords() {
		
		return dao.findAll();
	}

}
