package com.nit.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="AM_PhoneNumbers_Details")
@Setter
@Getter
public class PhoneNumber implements Serializable{
	@Id
	@GeneratedValue
	private Integer regNo;
	private Long phoneNumber;
	@Column(length = 20)
	private String NumberType;
	@Column(length = 20)
	private String provider;
	@Override
	public String toString() {
		return "PhoneNumber [regNo=" + regNo + ", phoneNumber=" + phoneNumber + ", NumberType=" + NumberType
				+ ", provider=" + provider + "]";
	}

	
}
