package com.nit.entity;

import java.io.Serializable;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="AM_Person_Info")
@Setter
@Getter
public class Person implements Serializable{
	
	@Id
	@SequenceGenerator(name = "gen1",initialValue = 1,allocationSize = 1,sequenceName = "PID_Seq")
	@GeneratedValue(generator = "gen1",strategy = GenerationType.IDENTITY)
	private Integer pid;
	@Column(length = 20)
	private String pname;
	@Column(length = 20)
	private String paddr;
	@OneToMany(targetEntity = PhoneNumber.class,cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name="Person_Id",referencedColumnName = "PID")
	private Set<PhoneNumber> phNumber;
	@Override
	public String toString() {
		return "Person [pid=" + pid + ", pname=" + pname + ", paddr=" + paddr + "]";
	}
	
	

	
}
