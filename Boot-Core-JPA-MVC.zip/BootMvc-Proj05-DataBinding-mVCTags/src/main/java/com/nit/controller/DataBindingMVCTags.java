package com.nit.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.nit.model.Employee;

@Controller
public class DataBindingMVCTags {

	@GetMapping("/")
	public String getMessage() {
		return "welcome";
	}
	
	@GetMapping("/register")
	public String registerEmp(@ModelAttribute("employee") Employee emp) {
		emp.setSalary(20000d);
		return "reg";
	}
	
	@PostMapping("/register")
	public String getregisterEmp(Map<String,Object> map,@ModelAttribute Employee emp) {
		System.out.println(emp);
		return "GetReg";
	}
}
