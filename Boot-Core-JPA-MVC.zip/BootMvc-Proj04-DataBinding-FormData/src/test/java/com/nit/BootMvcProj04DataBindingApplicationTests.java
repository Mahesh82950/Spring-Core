package com.nit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootMvcProj04DataBindingApplicationTests {

	@Test
	void contextLoads() {
	}

}
