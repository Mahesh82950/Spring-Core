package com.nit.model;

public class Employee {

	private Integer eid;
	private String ename;
	private double salary;
	private String add;
	
	public Employee(Integer eid, String ename, double salary, String add) {
		this.eid = eid;
		this.ename = ename;
		this.salary = salary;
		this.add = add;
	}
	public Integer getEid() {
		return eid;
	}
	public void setEid(Integer eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", salary=" + salary + ", add=" + add + "]";
	}
	
	
}
