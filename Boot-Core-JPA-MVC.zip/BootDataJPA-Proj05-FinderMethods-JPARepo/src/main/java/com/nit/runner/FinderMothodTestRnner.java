package com.nit.runner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.entity.Movie;
import com.nit.repository.IMovieRepository;

@Component
public class FinderMothodTestRnner implements CommandLineRunner{

	@Autowired
	private IMovieRepository iMovieMngtService;
	@Override
	public void run(String... args) throws Exception {
		Iterable <Movie> it=iMovieMngtService.findBymNAme("RRR");
		it.forEach(System.out::println);
//		
//		System.out.println("===============================================");
//		iMovieMngtService.findBymid(15).forEach(System.out::println);
		
//		System.out.println("===============================================");
//		iMovieMngtService.findByYearIn(List.of(2022, 2020)).forEach(System.out::println);
//		System.out.println("===============================================");
//		iMovieMngtService.findBymNAmeStartingWith("r").forEach(System.out::println);
		
//		System.out.println("===============================================");
//		iMovieMngtService.findBymNAmeEndingWith("a").forEach(System.out::println);
		
//		System.out.println("===============================================");
//		iMovieMngtService.findBymNAmeEndingWith("a").forEach(System.out::println);
		
//		System.out.println("===============================================");
//		iMovieMngtService.findByyear(2022).forEach(System.out::println);
		
//		System.out.println("===============================================");
//		iMovieMngtService.findBymNAmeLike("r%").forEach(System.out::println);
		
//		System.out.println("===============================================");
//		iMovieMngtService.findBymNAmeContaining("r").forEach(System.out::println);
//		System.out.println("===============================================");
//		iMovieMngtService.findByMidGreaterThanAndRatingLessThan(11, 8.5f).forEach(System.out::println);
		
//		System.out.println("===============================================");
//		iMovieMngtService.findBymNAmeStartingWithAndRatingBetween("k",4.0f, 8.0f).forEach(System.out::println);
		
	}

}
