package com.nit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nit.entity.Movie;

public interface IMovieRepository extends JpaRepository<Movie,Integer> {

	public List<Movie> findBymNAme(String name);
	public List<Movie> findBymid(Integer id);
	public Iterable<Movie> findByYearIn(List<Integer> list);
	public List<Movie> findBymNAmeStartingWith(String name);
	public List<Movie> findBymNAmeEndingWith(String str1);
	public Iterable<Movie> findByyear(Integer year);
	public List<Movie> findBymNAmeLike(String chars);
	public List<Movie> findBymNAmeContaining(String str);
	public Iterable<Movie> findByMidGreaterThanAndRatingLessThan(int mid,float rating);
	public Iterable<Movie> findBymNAmeStartingWithAndRatingBetween(String str,float start,float end);
}
