package com.nit.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.entity.Movie;
import com.nit.service.IMovieMngtService;

@Component
public class CurdRepositoryTestRunner implements CommandLineRunner {

	@Autowired
	private IMovieMngtService iMovieMngtService;
	@Override
	public void run(String... args) throws Exception {
	    Movie movie=new Movie();
	    movie.setRating(6f);
//	    movie.setMNAme("Natraj");
//		movie.setYear(2024);
//		try {
//		Iterable<Movie> it=iMovieMngtService.findMovieByOrder(true, "mNAme");
//		it.forEach(System.out::println);
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
//		try {
//			List <Integer> list=new ArrayList();
//			list.add(20);
//			list.add(21);
//			list.add(22);
//			list.add(60);
//			System.out.println(iMovieMngtService.deleteAllByIdInBatch(list));
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
		try {
			List<Movie> list =iMovieMngtService.searchMovieByMovie(movie, true, "mNAme");
			list.forEach(System.out::println);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		try {
			//System.out.println("18 id Movie is :: "+iMovieMngtService.getMovieById(18));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
}
	
}
