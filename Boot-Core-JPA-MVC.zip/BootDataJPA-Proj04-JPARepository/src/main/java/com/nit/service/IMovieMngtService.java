package com.nit.service;

import java.util.List;

import com.nit.entity.Movie;

public interface IMovieMngtService {
	public String deleteAllByIdInBatch(List<Integer> ids);
	public List<Movie> searchMovieByMovie(Movie movie,Boolean asc,String...prop);
	public Movie getMovieById(Integer id);

}
