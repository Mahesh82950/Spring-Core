package com.nit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.nit.entity.Movie;
import com.nit.repository.IMovieRepository;

@Service("imovieService")
public class IMovieMngServiceImpl implements IMovieMngtService {

	@Autowired
	private IMovieRepository  iMovieRepository;

	@Override
	public String deleteAllByIdInBatch(List<Integer> ids) {
		
		List<Movie> list=iMovieRepository.findAllById(ids);
		int count=list.size();
		iMovieRepository.deleteAllByIdInBatch(ids);
		if(count>0) {
		return count+" Movies Deleted ...";
		}
		else {
			return "Movies Not Found To Delete...";
		}
	}

	@Override
	public List<Movie> searchMovieByMovie(Movie movie, Boolean asc, String... prop) {
		Example example=Example.of(movie);
		Sort sort= Sort.by(asc?Direction.ASC:Direction.DESC,prop);
		List<Movie> list=iMovieRepository.findAll(example,sort);
		return list;
	}

	@Override
	public Movie getMovieById(Integer id) {
		Movie movie=iMovieRepository.getById(id);
		return movie;
	}

	
	

}
