package com.nit.runner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nit.repository.IMovieRepository;
import com.nit.view.ResultView1;
import com.nit.view.ResultView2;
import com.nit.view.ResultView3;

@Component
public class FinderMothodTestRnner implements CommandLineRunner{

	@Autowired
	private IMovieRepository iMovieMngtService;
	@Override
	public void run(String... args) throws Exception {

		System.out.println("===============================================");
		
		Iterable<ResultView1> it=iMovieMngtService.findBymNAmeIn(List.of("KGF","Charlee"), ResultView1.class);
		it.forEach(v1->{
			System.out.println(v1.getmNAme()+" "+v1.getMid());
		});
		System.out.println("===============================================");

		iMovieMngtService.findBymNAmeIn(List.of("KGF","Charlee"), ResultView2.class).forEach(v2->{
			System.out.println(v2.getmNAme()+" "+v2.getMid()+" "+v2.getRating());
		});
		System.out.println("===============================================");

		iMovieMngtService.findBymNAmeIn(List.of("KGF","Charlee"), ResultView3.class).forEach(v3->{
			System.out.println(v3.getmNAme()+" "+v3.getMid()+" "+v3.getYear());
		});
	}

}
