package com.nit.view;

public interface ResultView1 extends View {

	public String getmNAme();
	public Integer getMid();
}
