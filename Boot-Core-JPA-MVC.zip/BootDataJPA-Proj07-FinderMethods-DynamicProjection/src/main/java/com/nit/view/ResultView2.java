package com.nit.view;

public interface ResultView2 extends View {

	public String getmNAme();
	public Integer getMid();
	public Float getRating();
}
