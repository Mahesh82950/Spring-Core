package com.nit.view;

public interface View {

}
