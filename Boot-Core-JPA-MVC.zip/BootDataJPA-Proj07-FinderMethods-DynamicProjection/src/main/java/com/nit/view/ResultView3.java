package com.nit.view;

public interface ResultView3 extends ResultView1{
	public Integer getYear();

}
