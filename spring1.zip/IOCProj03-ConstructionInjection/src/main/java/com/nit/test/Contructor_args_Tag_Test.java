package com.nit.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.sbeans.WishMassageGenerator;

public class Contructor_args_Tag_Test {
public static void main(String[] args) {
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml");
	WishMassageGenerator generator=ctx.getBean("wmg", WishMassageGenerator.class);
	System.out.println(generator.genarateWish("mahesh"));
	ctx.close();
}
}

