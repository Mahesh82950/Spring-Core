package com.nit.sbeans;

import java.util.Date;

public class WishMassageGenerator {
	private Date date;

	public WishMassageGenerator(Date date) {
		System.out.println("WishMassageGenerator.(1-Param)Contructor()");
		this.date = date;
	}

	public WishMassageGenerator() {
		super();
		System.out.println("WishMassageGenerator-0 Param-contructor()");
	}

	public String genarateWish(String user) {
		int hours = date.getHours();
		if (hours < 12)
			return "Good Morning : " + user;
		else if (hours < 16)
			return "Good Afternoon :" + user;
		else if (hours < 20)
			return "Good Evening :" + user;
		else
			return "Good Night : " + user;
	}
}
