package com.nit.client;

import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.nit.sbeans.SeasonFinder;

public class DependancyInjectionTest {
	public static void main(String[] args) {
		FileSystemXmlApplicationContext cfx = new FileSystemXmlApplicationContext(
				"src/main/java/com/nit/cnfg/applicationContext.xml");
		Object obj = cfx.getBean("sf");
		SeasonFinder s1 = (SeasonFinder) obj;
		String result = s1.findSeason("Mahesh");
		System.out.println(result);
		cfx.close();
	}
}
