package com.nit.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.sbeans.CheckVoterEligiblity;

public class DeclarativeMethodTest {
public static void main(String[] args) {
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml"); 
	CheckVoterEligiblity cv=ctx.getBean("vote",CheckVoterEligiblity.class);
	System.out.println(cv.checkValidity());
	ctx.close();
}
}
