package com.nit.sbeans;

import java.util.Date;

public class CheckVoterEligiblity {
private String name;
private Integer age;
private String add;
private Date verivedOn;
public void setName(String name) {
	this.name = name;
}
public void setAge(Integer age) {
	this.age = age;
}
public void setAdd(String add) {
	this.add = add;
}
public void setVerivedOn(Date verivedOn) {
	this.verivedOn = verivedOn;
}


public void myInit() {
	System.out.println("CheckVoterEligiblity.myInit()");
	verivedOn=new Date();
	if(name==null) {
		throw new IllegalArgumentException("please provide name...");
	}
	if(add==null) {
		throw new IllegalArgumentException("please provide Address...");
	}
	if(age<=0||age>=125) {
		throw new IllegalArgumentException("please provide valid age...");
	}
}
public String checkValidity() {
	if(age>18) {
		return " [name=" + name + ", age=" + age + ", add=" + add + ", verivedOn=" + verivedOn + "\nVoter is Eligible.....";
		}
	return " [name=" + name + ", age=" + age + ", add=" + add + ", verivedOn=" + verivedOn + "\nVoter is  Not Eligible.....";

}
public void destroy() {
	name=null;
	age=null;
	add=null;
	verivedOn=null;
}
}
