package com.nit.com;

import java.util.Arrays;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("flipkart")
public class Flipkart {
//	@Value("${dep.comp}")
//	String str;
//	private Courior courior=(Courior)str;
	private Courior courior;
    @Autowired
    public Flipkart(@Qualifier("dtdc") Courior courior) {
        this.courior = courior;
        System.out.println("Flipkart.:: 0-param Constructor");
    }


	public String shopping(float prices[], String items[]) {
		float totalAmt = 0;
		for (int i = 0; i < prices.length; i++) {
			totalAmt += prices[i];
		}
		int ordId = new Random().nextInt(1000000);
		String status = courior.deliver(ordId);
		return Arrays.toString(items) + "\nAbove Items Are purchesed with prices of " + Arrays.toString(prices)
				+ " \nThe Total Billl Amount is :: " + totalAmt + "\n" + status;

	}

}
