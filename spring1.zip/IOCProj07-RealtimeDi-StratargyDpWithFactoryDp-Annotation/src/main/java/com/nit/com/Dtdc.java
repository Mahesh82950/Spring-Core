package com.nit.com;

import org.springframework.stereotype.Component;

@Component("dtdc")
public class Dtdc implements Courior{
	public Dtdc() {
		System.out.println("Dtdc::0-param Contructor()");
	}

	@Override
	public String deliver(int ordID) {
		return "Order Delivered With Order ID : "+ordID+" Using Dtdc Services";
	}

}
