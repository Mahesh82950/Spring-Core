package com.nit.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.com.Flipkart;


public class StatergyDpTest {
public static void main(String[] args) {
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml");
	Flipkart fpkt1=ctx.getBean("flipkart", Flipkart.class);
	String res=fpkt1.shopping(new float[] {2000.0f,1200.0f,2300.0f}, new String[] {"Shirt","Trouser","Shoes"});
	System.out.println(res);
	ctx.close();
}
}
