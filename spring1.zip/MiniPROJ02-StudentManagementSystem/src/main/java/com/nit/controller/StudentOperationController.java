package com.nit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.nit.model.Students_Info;
import com.nit.service.IStudentMGMTServices;

@Controller("stuController")
public class StudentOperationController {
	@Autowired
private IStudentMGMTServices istu;
	public String  processCustomer(Students_Info stu)throws Exception{
		String result=istu.registerStudent(stu);
		return result;
	}

}
