package com.nit.model;

public class Students_Info {
private Integer sid;
private String fname;
private String lname;
private String sadd;
private Integer mMarks;
private Integer pMarks;
private Integer sMarks;
private Double percentage;
public Integer getSid() {
	return sid;
}
public void setSid(Integer sid) {
	this.sid = sid;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public String getSadd() {
	return sadd;
}
public void setSadd(String sadd) {
	this.sadd = sadd;
}
public Integer getmMarks() {
	return mMarks;
}
public void setmMarks(Integer mMarks) {
	this.mMarks = mMarks;
}
public Integer getpMarks() {
	return pMarks;
}
public void setpMarks(Integer pMarks) {
	this.pMarks = pMarks;
}
public Integer getsMarks() {
	return sMarks;
}
public void setsMarks(Integer sMarks) {
	this.sMarks = sMarks;
}
public Double getPercentage() {
	return percentage;
}
public void setPercentage(Double percentage) {
	this.percentage = percentage;
}

}
