package com.nit.test;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.controller.StudentOperationController;
import com.nit.model.Students_Info;

public class RealTimeDITest01 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Student RollNo ::");
	int rollno=sc.nextInt();
	System.out.println("Enter Student Fname ::");
	String fname=sc.next();
	System.out.println("Enter Student Lname ::");
	String lname=sc.next();
	System.out.println("Enter Student Address ::");
	String sadd=sc.next();
	System.out.println("Enter Student Math Marks ::");
	int mMarks=sc.nextInt();
	System.out.println("Enter Student Physics Marks ::");
	int pMarks=sc.nextInt();
	System.out.println("Enter Student Science Marks ::");
	int sMarks=sc.nextInt();
	Students_Info st=new Students_Info();
	st.setSid(rollno);
	st.setFname(fname);
	st.setLname(lname);
	st.setSadd(sadd);
	st.setmMarks(mMarks);
	st.setpMarks(pMarks);
	st.setsMarks(sMarks);
	
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml");
	StudentOperationController stu=ctx.getBean("stuController",StudentOperationController.class);
	try {
		System.out.println(stu.processCustomer(st));
		System.out.println(System.getProperties());
	} catch (Exception e) {
		
		e.printStackTrace();
	}
	sc.close();
	ctx.close();
}
}
