package com.nit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.model.Students_Info;
import com.nit.studentDAo.IStudentDAO;
@Service("stuService")
public class StudentMGMTServiceImp implements IStudentMGMTServices{
	@Autowired
	private IStudentDAO stuDao;
	@Override
	public String registerStudent(Students_Info stu) throws Exception {
		double total=stu.getmMarks()+stu.getpMarks()+stu.getsMarks();
		double percentage=total/300*100;
		
		stu.setPercentage(percentage);
		int count=stuDao.insert(stu);
		return count==0?"Registration Faliled Please Try Again":"Student Register With The Percentage of :: "+stu.getPercentage()+" \nStudent RollNo :: "+stu.getSid()+" \nMarks[Math,Physics,Science] :: "+"[ "+stu.getmMarks()+" "+stu.getpMarks()+" "+stu.getsMarks()+" ]";
	}

}
