package com.nit.service;

import com.nit.model.Students_Info;

public interface IStudentMGMTServices {
	public String registerStudent(Students_Info stu)throws Exception;
}

