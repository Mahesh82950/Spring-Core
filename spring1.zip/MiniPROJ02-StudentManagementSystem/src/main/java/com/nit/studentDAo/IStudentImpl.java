package com.nit.studentDAo;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nit.model.Students_Info;

@Repository("stuDAO")
public class IStudentImpl implements IStudentDAO {
	@Autowired
	private DataSource ds;
	private static final String INSERT_QUERY = "Insert into student values(?,?,?,?,?,?,?,?)";
	int result = 0;

	@Override

	public int insert(Students_Info stu) throws Exception {
		try (Connection con = ds.getConnection(); PreparedStatement ps = con.prepareStatement(INSERT_QUERY)) {
			ps.setInt(1, stu.getSid());
			ps.setString(2, stu.getFname());
			ps.setString(3, stu.getLname());
			ps.setString(4, stu.getSadd());
			ps.setInt(5, stu.getmMarks());
			ps.setInt(6, stu.getpMarks());
			ps.setInt(7, stu.getsMarks());
			ps.setDouble(8, stu.getPercentage());
			result=ps.executeUpdate();
		}
		return result;
	}

}
