package com.nit.studentDAo;

import com.nit.model.Students_Info;

public interface IStudentDAO {
public int insert(Students_Info stu)throws Exception;
}
