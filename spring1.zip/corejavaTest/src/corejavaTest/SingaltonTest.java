package corejavaTest;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class SingaltonTest {
public static void main(String[] args) {
	
	PrinterTest_Singalton printer1=PrinterTest_Singalton.getInstance();
	PrinterTest_Singalton printer2=PrinterTest_Singalton.getInstance();
	printer1.print();
	printer2.print();
	System.out.println(printer1.hashCode()+" "+printer2.hashCode());
	System.out.println(printer1==printer2);
	System.out.println("\n=========================Using reflection=======================\n");
	PrinterTest_Singalton printer3=null;
	try {
		Constructor<PrinterTest_Singalton> construtor=PrinterTest_Singalton.class.getDeclaredConstructor();
		construtor.setAccessible(true);
		printer3=construtor.newInstance();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 

	printer3.print();
	System.out.println(printer1.hashCode()+" "+printer3.hashCode());
	System.out.println(printer1==printer3);
}
}
