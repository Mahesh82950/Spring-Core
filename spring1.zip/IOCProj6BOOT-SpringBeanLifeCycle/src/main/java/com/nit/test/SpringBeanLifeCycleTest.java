package com.nit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nit.config.AppConfig;
import com.nit.sbeans.MarrageEligiblityCheck;

public class SpringBeanLifeCycleTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext acc = new AnnotationConfigApplicationContext(AppConfig.class);
		MarrageEligiblityCheck marrageEligiblityCheck = acc.getBean("marrage", MarrageEligiblityCheck.class);
		String result = marrageEligiblityCheck.checkMarrageEligiblity();
		System.out.println(result);
		acc.close();
	}
}