package com.nit.sbeans;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

@Component("marrage")
@PropertySource("com/nit/commans/info.properties")
public class MarrageEligiblityCheck {
	@Value("${male.name}")
	private String mName;
	@Value("${female.name}")
	private String fName;
	@Value("${male.age}")
	private int mAge;
	@Value("${female.age}")
	private int fAge;
	private Date date;

	public MarrageEligiblityCheck() {
		System.out.println("MarrageEligiblityCheck:: 0-param Constructor....");
	}

	@PostConstruct
	public void myInit() {
		date = new Date();
		if (mAge > 125 || mAge < 0 || fAge > 125 || fAge < 0 || fName == null || mName == null) {
			throw new IllegalArgumentException("Please Provide Valid Age/Name....");
		}
	}

	public String checkMarrageEligiblity() {
		if (mAge >= 21 && fAge >= 18) {
			return fName + " And " + mName + " Are Eligible For Marrege....Verefied On Date :: " + date;
		}
		return fName + " And " + mName + " Are Not Eligible For Marrege....Verefied On Date :: " + date;
	}

	@PreDestroy
	public void myDestroy() {
		fName = null;
		mName = null;
		fAge = 0;
		mAge = 0;
		date = null;
	}

}
