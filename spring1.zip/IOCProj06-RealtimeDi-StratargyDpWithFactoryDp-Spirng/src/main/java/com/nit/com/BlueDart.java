package com.nit.com;

public class BlueDart implements Courior{

	public BlueDart() {
	     System.out.println("BlueDart::0-param Constructor");
	}

	@Override
	public String deliver(int ordID) {
		return "Order Delivered with OrderID :"+ ordID+" Using BlueDart Service";
	}

	
}
