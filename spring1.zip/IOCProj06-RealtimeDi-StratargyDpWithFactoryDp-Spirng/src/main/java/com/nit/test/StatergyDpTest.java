package com.nit.test;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.com.Flipkart;


public class StatergyDpTest {
public static void main(String[] args) {
	DefaultListableBeanFactory dlb=new DefaultListableBeanFactory();
	XmlBeanDefinitionReader xbd=new XmlBeanDefinitionReader(dlb);
	xbd.loadBeanDefinitions("com/nit/cfgs/applicationContext.xml");
//	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml");
	Flipkart fpkt=dlb.getBean("fpkt", Flipkart.class);
	String res=fpkt.shopping(new float[] {2000.0f,1200.0f,2300.0f}, new String[] {"Shirt","Trouser","Shoes"});
	System.out.println(res);
}
}
