package com.nit.beans;

import org.springframework.stereotype.Component;

@Component("petrol")
public class Petrol implements Engine{

	public Petrol() {
		System.out.println("Petrol:: 0-param Constructor...");
	}

	@Override
	public void start() {
		System.out.println("Petrol::Engine Started...");
		
	}

	@Override
	public void stop() {
		System.out.println("Petrol::Engine Stopped...");		
	}
	

}
