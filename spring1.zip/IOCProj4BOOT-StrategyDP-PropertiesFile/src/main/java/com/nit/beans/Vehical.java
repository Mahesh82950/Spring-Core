package com.nit.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Vehical {

	public Vehical() {
		System.out.println("Vehical:: 0-param Constructor....");
	}

	@Autowired
	@Qualifier("engineType")
	private Engine engine;

	public void travel(String start, String stop) {
		engine.start();
		System.out.println("Journey Stated At :: " + start);

		engine.stop();
		System.out.println("Journey Stopped At :: " + stop);
	}

}
