package com.nit.beans;

import org.springframework.stereotype.Component;

@Component("diesel")
public class Diesel implements Engine{

	public Diesel() {
		System.out.println("Diesel:: 0-param Constructor...");
	}

	@Override
	public void start() {
		System.out.println("Diesel::Engine Started...");
		
	}

	@Override
	public void stop() {
		System.out.println("Diesel::Engine Stopped...");		
	}
	

}
