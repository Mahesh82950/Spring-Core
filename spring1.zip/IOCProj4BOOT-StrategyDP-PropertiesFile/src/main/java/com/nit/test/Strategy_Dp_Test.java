package com.nit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nit.beans.Vehical;
import com.nit.config.AppConfig;

public class Strategy_Dp_Test {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext acc=new AnnotationConfigApplicationContext(AppConfig.class);
		Vehical vehical=acc.getBean("vehical",Vehical.class);
		System.out.println("======================================================================");
		vehical.travel("Hydrabad", "Nanded");
		acc.close();
	}
}
