package demoString01;

public class SumOfEncryptedIntegers$3079 {
	public static void main(String[] args) {

		int nums[]= {1,2,3}; //{10,21,31};
	    int c=0;
	    for(int i=0;i<nums.length;i++)
	    {
	        c=0;
	        int max=0;
	        int temp=0;
	        int temp2=nums[i];
	        while(temp2!=0)
	        {
	            temp=temp2%10;
	            c++;
	            temp2/=10;
	            if(temp>max){
	                max=temp;
	            }
	            
	        }
	        if(c!=1){
	        int temp3=0;
	        while(c!=0)
	        {
	            temp3=temp3*10+max;
	            c--;
	        }
	        nums[i]=temp3;
	        }


	    }
	    int sum=0;
	    for(int i=0;i<nums.length;i++)
	    {
	        sum+=nums[i];
	    }
	    System.out.println(sum);
	}
}
