package demoString01;

public class NumberSeniorCitizens$2678 {
public static void main(String[] args) {
	int count=0;
	String [] str = {"7868190130M7522","5303914400F9211","9273338290F4010"};
	for(int i=0;i<str.length;i++) {
		if(str[i].charAt(11)>='6') {
			count++;
		}
	}
	System.out.println(count);

}
}
