package demoString01;

import java.util.HashMap;
import java.util.Map;

public class REformatDate$1507 {
public static void main(String[] args) {
	String date="6th Jun 1933";
	String[] s = date.split(" ");
	Map<String,String> m1=new HashMap<String,String>();
    m1.put("Jan","01");
    m1.put("Feb","02");
    m1.put("Mar","03");
    m1.put("Apr","04");
    m1.put("May","05");
    m1.put("Jun","06");
    m1.put("Jul","07");
    m1.put("Aug","08");
    m1.put("Sep","09");
    m1.put("Oct","10");
    m1.put("Nov","11");
    m1.put("Dec","12");
    String d=s[0];
    String ans=s[2]+"-"+m1.get(s[1])+"-";
    System.out.println(ans);
    String s2="";
    if(d.length()==3) {
    	s2+="0"+d.charAt(0);
    }
    if(d.length()==4) {
    	s2+=d.charAt(0)+""+d.charAt(1);
    }
    ans+=s2;
    System.out.println(ans);
}
}
