package demoString01;

import java.util.HashMap;
import java.util.Map;

public class KthDistinctStringInanArray$2053 {
public static void main(String[] args) {
	String [] str= {"d","b","c","b","c","a"};
	int k=2;
	Map<String,Integer> m1=new HashMap<String,Integer>();
	for(int i=0;i<str.length;i++) {
		if(m1.containsKey(str[i])) {
			m1.put(str[i], m1.get(str[i])+1);
		}else {
		m1.put(str[i], 1);
		}
		}
	int j=0;
	for(int i=0;i<str.length;i++) {
		if(m1.get(str[i])==1&&++j==k) {
			
				System.out.println(str[i]);
			
		}
	}
	System.out.println(m1);
}
}
