package demoString01;

public class SubStringContains {
	public static void main(String[] args) {
		String str01="haystack";
		String str02="stack";
		int index=0;
			if(str01.contains(str02))
		{
			
			index=str01.indexOf((int)str02.charAt(0));
			
			System.out.println(index);
			
		}
		else {
			System.out.println("not substring");
		}
	}

}
