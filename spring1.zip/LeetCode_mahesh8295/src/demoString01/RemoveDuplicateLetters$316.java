package demoString01;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class RemoveDuplicateLetters$316 {

	public static void main(String[] args) {
		String str="cbacdcbc";
		String s="";
		char []ch=str.toCharArray();
		Set<Character> s1=new HashSet<>();
		for(int i=0;i<ch.length;i++) {
			s1.add(ch[i]);
		}
		Iterator i1=s1.iterator();
		while(i1.hasNext()) {
			s+=i1.next();
		}
		System.out.println(s);
	}
}
