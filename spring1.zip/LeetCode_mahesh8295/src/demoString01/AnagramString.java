package demoString01;

import java.util.Arrays;

public class AnagramString {
	public static void main(String[] args) {
		String s = "anagram";
		String t = "nagaram";
		String s1="";
		String s2="";
		char ch1[]=s.toCharArray();
		Arrays.sort(ch1);
		char ch2[]=t.toCharArray();
		Arrays.sort(ch2);
		
		for(int i=0;i<ch1.length;i++)
		{
			s1+=ch1[i];
		}
		for(int i=0;i<ch2.length;i++)
		{
			s2+=ch2[i];
		}
		System.out.println(s1+" "+s2);
		if(s1.equals(s2))
		{
			System.out.println("hellow");
		}
		
	}

}
