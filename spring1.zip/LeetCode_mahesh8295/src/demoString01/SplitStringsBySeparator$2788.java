package demoString01;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SplitStringsBySeparator$2788 {
public static void main(String[] args) {
	List<String> words=new ArrayList<String>();
	words.add("one.two.three");
	words.add("four.five");
	words.add("six");
	char separator='.';
	List<String> words2=new ArrayList<String>();
	String sep = "\\" + separator;
	for(int i=0;i<words.size();i++){
		String str[]=words.get(i).split(sep);
		for(int j=0;j<str.length;j++){
		if(str[j].length()>0) words2.add(str[j]);
		}
		}
	System.out.println(words2);
	
}
}
