package demoString01;

public class LeetCode$551 {

	public static void main(String[] args) {
		String str= "PPALLP";
		int absentCount=0;
		int lateCount=0;
		int presentCount=0;
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='P')presentCount++;
			if(str.charAt(i)=='A')absentCount++;
			if(str.charAt(i)=='L')lateCount++;
			else lateCount=0;
			if(absentCount>=2||lateCount>2)
				{
				   System.out.println("Student not Eligibal(his absentcount ||lateCount is >2");
				   absentCount=-1;
				}
		}
		if(absentCount!=-1&&presentCount>3)
		{
			System.out.println("Student is Eligibale(his attendance is more than 3)");
		}
		
	}
}
