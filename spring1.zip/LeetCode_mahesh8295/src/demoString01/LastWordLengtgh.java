package demoString01;

public class LastWordLengtgh {

	public static void main(String[] args) {
		String str="  Hello World    ";
		str.trim();
	
		String []a=str.split("\\s");
		
		String s1=a[a.length-1];
		int s=s1.length();
		System.out.println(s);
	}
}
