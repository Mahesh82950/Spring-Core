package demoString01;

public class LeetCode$389 {
	public static void main(String[] args) {
		String str="abcd";
		String str2="abcde";
		char a[]=str2.toCharArray();
		for(int i=0;i<a.length;i++)
		{
			if(!str.contains(a[i]+"")){
				System.out.println(a[i]);
				
			}
		}
	}

}
