package demoString01;

public class LeettCode833 {
public static void main(String[] args) {
	String s = "abcd";
	int[] indices = {0, 2};
	String[] sources = {"a", "cd"};
	String[] targets = {"eee", "ffff"};
	String str="";
	
	
}
}
