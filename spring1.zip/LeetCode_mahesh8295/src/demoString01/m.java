package demoString01;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class m {
	public static void main(String[] args) {
		String str="23";
		Map<String, String> m1 = new HashMap<>();
		m1.put("2", "abc");
		m1.put("3", "def");
		m1.put("4", "ghi");
		m1.put("5", "jkl");
		m1.put("6", "mno");
		m1.put("7", "pqrs");
		m1.put("8", "tuv");
		m1.put("9", "wxyz");
		String s="";
		for(int i=0;i<str.length();i++) {
			s+=m1.get(str.charAt(i)+"");
		}
		System.out.println(s);
		List<String> l1=new ArrayList<>();
//    String arr[] = new String[len*(len+1)/2];  
//    
    for(int i = 0; i < s.length(); i++) {  
        for(int j = i; j < s.length(); j++) {  
            String str2= s.substring(i, j+1);  
            l1.add(str2);
        }  
	}
    System.out.println(l1);
	}
}
