package demoString01;

public class ScoreOfString$3110 {

	public static void main(String[] args) {
		String str="hello";
		int score=0;
		char[] a=str.toCharArray();
		for(int i=0;i<a.length-1;i++)
		{
			score+=Math.abs(a[i]-a[i+1]);
			//System.out.println(a[i]+" "+a[i+1]);
		}
		System.out.println(score);
	}
}
