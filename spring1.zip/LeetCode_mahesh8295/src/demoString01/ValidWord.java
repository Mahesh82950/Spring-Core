package demoString01;

public class ValidWord {

	public boolean isValid(String str) {
        int vovelcount=0;
		int conscount=0;
		int digitcount=0;
		char[] ch=str.toCharArray();
		if(str.length()<3)return false;
		for(int i=0;i<ch.length;i++)
		{
			
            if((ch[i]>='a' && ch[i]<='z') || (ch[i]>='A' && ch[i]<='Z')){
			if(ch[i]=='a' || ch[i]=='A' || ch[i]=='e' || ch[i]=='E' || ch[i]=='i' || ch[i]=='I' || ch[i]=='o' || ch[i]=='O' || ch[i]=='u' || ch[i]=='U') {
				vovelcount++;
			}
			else {
				conscount++;
			}
            }
		   else if(ch[i]>='0'&&ch[i]<='9') {
				digitcount++;
			}
            else{
                return false;
            }
		}
        if(vovelcount>=1&&conscount>=1)return true;

        return false;
        
    }
	
}
