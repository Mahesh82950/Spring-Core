package demoString01;

public class ValidPalindrom$125 {

	public static void main(String[] args) {
//		String str="A man, a plan, a canal: Panama";
		String str="race a car";
		String str2="";
		for(int i=0;i<str.length();i++)
		{
			if((str.charAt(i)>=65&&str.charAt(i)<=90)||(str.charAt(i)>=97&&str.charAt(i)<=122)) {
				if(str.charAt(i)>=65&&str.charAt(i)<=90) {
					char ch=(char) (32+str.charAt(i));
					str2+=(char)ch;
				}
				else {
					str2+=str.charAt(i);
				}
			}
		}
		boolean flag=true;
		for(int i=0;i<str2.length()/2;i++) {
			if(str2.charAt(i)!=str2.charAt(str2.length()-1-i)) {
				flag=false;
				System.out.println("not palindrom");
				break;
			}
			
		}
		if(flag) {
			System.out.println(" palindrom");
		}
	}
}
