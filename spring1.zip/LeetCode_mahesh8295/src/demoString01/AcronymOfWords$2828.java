package demoString01;

import java.util.ArrayList;
import java.util.List;

public class AcronymOfWords$2828 {
	public static void main(String[] args) {
		List<String> words=new ArrayList<String>();
		//{"alice","bob","charlie"}
		words.add("alice");
		words.add("bob");
		words.add("charlie");
		String str1="abc";
		String str2="";
		for(int i=0;i<words.size();i++)
		{
			str2+=words.get(i).charAt(0);
		}
		if(str1.equals(str2))
		{
			System.out.println("equal");
		}
	}

}
