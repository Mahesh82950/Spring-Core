package demoString01;

import java.util.ArrayList;
import java.util.List;

public class SubStringWithConcatAllWords {
	public static void main(String[] args) {
//		String s="barfoothefoobarman";
//		String []words= {"foo","bar"};
//		 String str="";
//	        for(int i=0;i<words.length;i++)
//	        {
//	            str+=words[i];
//	        }
//	        System.out.println(str);
//	        List<Integer> l1=new ArrayList<Integer>();
//	        if(s.contains(str))
//	        {
//	        	int index=s.indexOf(str);
//	        	System.out.println(index);
//	        	int index2=s.lastIndexOf(str);
//	        	l1.add(index);
//	        	l1.add(index2);
//
//	        }
//	        System.out.println(l1);
		
	}

}
