package demoString01;

import java.util.HashMap;
import java.util.Map;

public class ReverseWordsString$151 {
public static void main(String[] args) {
	String str="a good   example";
	str=str.trim();
	String []s=str.split("\\s");
	String str2="";
	for(int i=s.length-1;i>=0;i--) {
		s[i]=s[i].trim();
		str2+=s[i]+" ";
	}
	System.out.println(str2);
	
	
	
}
}
