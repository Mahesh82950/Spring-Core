package demoString01;

public class FirstUniqueCharacter {
public static void main(String[] args) {
	String str="loveleetcode";
	char []a=str.toCharArray();
	int c=0;
	for(int i=0;i<a.length;i++)
	{c=0;
		for(int j=0;j<a.length;j++)
		{
			if(a[i]==a[j]&&i!=j)
			{
				c++;
			}
		}
		if(c==0)
		{
			System.out.println(i);
			
		}
	}
}
}
