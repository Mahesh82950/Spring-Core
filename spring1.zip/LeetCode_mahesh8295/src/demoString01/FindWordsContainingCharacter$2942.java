package demoString01;

import java.util.ArrayList;
import java.util.List;

public class FindWordsContainingCharacter$2942 {

	public static void main(String[] args) {
		String []words ={"leet","code"};
		char ch='e';
		List<Integer> l1=new ArrayList<Integer>();
		for(int i=0;i<words.length;i++)
		{
			for(int j=0;j<words[i].length();j++) {
			if(words[i].charAt(j)==ch)
			{
				l1.add(i);
				break;
			}
			}
		}
		System.out.println(l1);
	}
}
