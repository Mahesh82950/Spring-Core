package demoString01;

public class MaxProductOfWordLength {
public static void main(String[] args) {
	String []words = {"abcw","baz","foo","bar","xtfn","abcdef"};
	int product=1;
	int p=1;
	int c=0;
	for(int i=0;i<words.length;i++)
	{
		for(int j=i+1;j<words.length;j++)
		{
			for(int k=0;k<words[i].length();k++)
			{
					if(words[j].contains(words[i].charAt(k)+""))
					{
						c++;
					}
				
			}
			if(c==0)
			{
				p=words[i].length()*words[j].length();
				System.out.println(words[i]+" "+words[j]);
			}
		}
		if(p>product)
		{
			product=p;
		}
	}
	System.out.println(product);
}
}
