package demoString01;

public class ValidParantesis {

	public static void main(String[] args) {
		char ch='(';
		char ch1=')';
		int c=0;
		int c1=0;
		String str="()";
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)==ch)
			{
				c++;
			}
			if(str.charAt(i)==ch1)
			{
				c1++;
			}
		}
		if(c1>=c)
		{
			System.out.println("Valid");
		}
		
	}
}
