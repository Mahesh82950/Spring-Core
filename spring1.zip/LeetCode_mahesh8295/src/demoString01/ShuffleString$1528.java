package demoString01;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class ShuffleString$1528 {
public static void main(String[] args) {
	String str="codeleet";
	int [] a= {4,5,6,7,0,2,1,3};
	Map<Integer,Character> m1=new HashMap<Integer,Character>();
	char[] ch=str.toCharArray();
	for(int i=0;i<ch.length;i++) {
	m1.put(a[i], ch[i]);
	}
	Arrays.sort(a);
	String str2="";
	for(int i=0;i<a.length;i++) {
		str2+=m1.get(a[i]);
	}
	System.out.println(str2);
	System.out.println("ShuffleString$1528.main()");
}
}
