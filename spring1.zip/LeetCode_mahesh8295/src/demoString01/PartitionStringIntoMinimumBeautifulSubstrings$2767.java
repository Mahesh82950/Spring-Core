package demoString01;

public class PartitionStringIntoMinimumBeautifulSubstrings$2767 {

	public static void main(String[] args) {
		String str="1011";
		 int len = str.length();  
	        int temp = 0;  
	       
	        String arr[] = new String[len*(len+1)/2];  
	          
	        for(int i = 0; i < len; i++) {  
	            for(int j = i; j < len; j++) {  
	                arr[temp] = str.substring(i, j+1);  
	                temp++;  
	            }  
	        }
	        int count=0;
	        for(int i=0;i<arr.length;i++)
	        {
	        	System.out.println(arr[i]);
	            if(arr[i].charAt(0)!=0&&arr[i].charAt(arr[i].length()-1)!=0)
	            {
	            	//System.out.println(arr[i]);
	            	count++;
	            }
	        }  
	        System.out.println(count);
	}
}
