package demoArray01;

import java.util.HashMap;
import java.util.Map;

public class SortArrayByIncreasingFrequency$1636 {
	public static void main(String[] args) {
		int []nums= {1,1,2,2,2,3};
		Map<Integer,Integer> m1=new HashMap<Integer,Integer>();
	        for(int i=0;i<nums.length;i++){
	        	int c=0;
	            for(int j=0;j<nums.length;j++){
	                if(nums[i]==nums[j]){
	                    c++;
	                }
	            }
	            m1.put(c, nums[i]);
	            System.out.println(nums[i]+" "+c);
	        }
	        System.out.println(m1);
	}

}
