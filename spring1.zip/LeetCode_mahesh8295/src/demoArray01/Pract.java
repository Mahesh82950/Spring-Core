package demoArray01;

public class Pract {

}
