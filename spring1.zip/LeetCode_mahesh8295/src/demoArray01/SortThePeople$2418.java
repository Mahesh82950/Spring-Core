package demoArray01;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class SortThePeople$2418 {

	public static void main(String[] args) {
		String[] names = {"Mary","John","Emma"};
		int []heights = {180,165,170};
		Map<Integer,String> m1=new HashMap<Integer,String>();
		String[] result=new String[names.length];
		for(int i=0;i<heights.length;i++) {
			m1.put(heights[i], names[i]);
			}
			Arrays.sort(heights);
			
			for(int k=0;k<names.length;k++) {
			result[names.length-1-k]=m1.get(heights[k]);	
			}
		
		System.out.println(Arrays.toString(result));
	}
}
