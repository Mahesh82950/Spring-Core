package demoArray01;

import java.util.Arrays;

public class SumofSquareNumbers$633 {

	public static void main(String[] args) {
//		int c=5;
//		Set<Integer> s1=new HashSet<Integer>();
//		for(int i=0;i<=c;i++) {
//			s1.add(i*i);
//			
//		}
//		for(int i=0;i<=c;i++) {
//			int temp=i*i;
//			if(s1.contains(c-temp)) {
//				System.out.println("hellow");
//			}
//		}
		String ransomNote="ahe";
		String magazine="mahesh";
		char[] ch=ransomNote.toCharArray();
        Arrays.sort(ch);
        String ransomNote2=ch.toString();
        char[] ch2=magazine.toCharArray();
        Arrays.sort(ch2);
        String magazine2=ch2.toString();
        System.out.println(magazine2.contains(ransomNote2));
	}
}
