package demoArray01;

public class ValidParenthesis$20 {

	public static void main(String[] args) {
		String str="(){}[]";
		char ch[]=str.toCharArray();
		while(str.contains("()")||str.contains("[]")||str.contains("{}")) {
			str=str.replace("()", "");
			str=str.replace("{}", "");
			str=str.replace("[]", "");
		}
		if(str.isEmpty()) {
			System.out.println("Valid parenthesis...");
		}
		else {
			System.out.println("Not Valid parenthesis...");
		}
//		int brace1=0;
//		int brace2=0;
//		int curlybrace1=0;
//		int curlybrace2=0;
//		int squarebrace1=0;
//		int squarebrace2=0;
//		for(int i=0;i<ch.length;i++) {
//			if(ch[i]=='(') {
//				brace1++;
//			}
//			else if(ch[i]==')') {
//				brace2++;
//			}
//			else if(ch[i]=='{') {
//				curlybrace1++;
//			}
//			else if(ch[i]=='}') {
//				curlybrace2++;
//			}
//			else if(ch[i]=='[') {
//				squarebrace1++;
//			}
//			else if(ch[i]==']') {
//				squarebrace2++;
//			}
//		}
//		if(brace1==brace2&&curlybrace1==curlybrace2&&squarebrace1==squarebrace2) {
//			System.out.println("valid parenthesis...");
//		}
//		else {
//			System.out.println("Not valid parenthesis...");
//		}
		
	}
}
