package demoArray01;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Permutaion$28 {

	public static void main(String[] args) {
		int []nums= {1,2,3};
		List<Integer> l1=new ArrayList<Integer>();
		 List<List<Integer>> l2=new ArrayList<List<Integer>>();
		int m=0;
		for(int i=0;i<nums.length;i++)
		{
			for(int j=0;j<nums.length;j++)
			{
				for(int k=0;k<nums.length;k++)
				{
					if(i!=j&&j!=k&&i!=k)
					{
						//System.out.println(nums[i]+" "+nums[j]+" "+nums[k]);
						l1.add(nums[i]);
						l1.add(nums[j]);
						l1.add(nums[k]);
						
						 l2.add(new ArrayList<Integer>(Arrays.asList(nums[i],nums[j],nums[k])));
					}
				}
			}
		}
		System.out.println(l2);
	}
}
