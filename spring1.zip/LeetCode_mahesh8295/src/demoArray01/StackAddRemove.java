package demoArray01;

import java.util.Stack;

public class StackAddRemove {

	public static void main(String[] args) {
		Stack s1=new Stack();
		s1.add(100);
		s1.add(200);
		s1.add(300);
		s1.add(400);
		s1.add(500);
		System.out.println(s1);
		s1.push(800);
		System.out.println(s1);
		System.out.println(s1.pop());
		System.out.println(s1.peek());
		
	}
}
