package com.nit.model;

public class Cust_Info {
	private Integer custId;
	private String custName;
	private String custAdd;
	private Double pAmount;
	private Double rInterest;
	private Integer time;
	private Double sInterest;

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAdd() {
		return custAdd;
	}

	public void setCustAdd(String custAdd) {
		this.custAdd = custAdd;
	}

	public Double getpAmount() {
		return pAmount;
	}

	public void setpAmount(Double pAmount) {
		this.pAmount = pAmount;
	}

	public Double getrInterest() {
		return rInterest;
	}

	public void setrInterest(Double rInterest) {
		this.rInterest = rInterest;
	}

	public Integer getTime() {
		return time;
	}

	public void setTime(Integer time) {
		this.time = time;
	}

	public Double getsInterest() {
		return sInterest;
	}

	public void setsInterest(Double sInterest) {
		this.sInterest = sInterest;
	}

	@Override
	public String toString() {
		return "Cust_Info [custId=" + custId + ", custName=" + custName + ", custAdd=" + custAdd + ", pAmount="
				+ pAmount + ", rInterest=" + rInterest + ", time=" + time + ", sInterest=" + sInterest + "]";
	}

}
