package com.nit.service;

import com.nit.dao.ICustomerDao;
import com.nit.model.Cust_Info;

public class CustomerServiceImpl implements ICustomerService{

	private ICustomerDao custDAo;
	
	
	public CustomerServiceImpl(ICustomerDao custDAo) {
		this.custDAo = custDAo;
	}
	@Override
	public String registerCustomer(Cust_Info cust) throws Exception {
		try {
		double sInterrest=(cust.getpAmount()*cust.getrInterest()*cust.getTime())/100;
		cust.setsInterest(sInterrest);
		int result=custDAo.insert(cust);
		return result==0?"Registration Failed....":"Customer Register SuccessFully. "+cust.toString();
		}
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
