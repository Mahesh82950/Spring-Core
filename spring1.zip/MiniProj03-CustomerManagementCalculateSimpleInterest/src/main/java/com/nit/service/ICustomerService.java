package com.nit.service;

import com.nit.model.Cust_Info;

public interface ICustomerService {
public String registerCustomer(Cust_Info cust)throws Exception;
}
