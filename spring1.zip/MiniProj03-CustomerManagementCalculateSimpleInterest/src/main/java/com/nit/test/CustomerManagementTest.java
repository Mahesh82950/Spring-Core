package com.nit.test;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.controller.MainCustomerController;
import com.nit.model.Cust_Info;

public class CustomerManagementTest {
public static void main(String[] args) {
	
	try(ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml");
		
			Scanner sc=new Scanner(System.in);){
		MainCustomerController custController=ctx.getBean("main",MainCustomerController.class);
		Cust_Info cust=new Cust_Info();
		System.out.println("Enter Customer Id ::");
		int custId=sc.nextInt();
		System.out.println("Enter Customer Name::");
		String name=sc.next();
		System.out.println("Enter Customer Address ::");
		String add=sc.next();
		System.out.println("Enter Principal Amount");
		double pAmount=sc.nextDouble();
		System.out.println("Enter the Rate of Interest ::");
		double rate=sc.nextDouble();
		System.out.println("Enter the Period of amount(In Years Only)::");
		int time=sc.nextInt();
		cust.setCustId(custId);
		cust.setCustName(name);
		cust.setCustAdd(add);
		cust.setpAmount(pAmount);
		cust.setrInterest(rate);
		cust.setTime(time);
		String result=custController.processCustomer(cust);
		System.out.println(result);
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}
}
