package com.nit.controller;

import com.nit.model.Cust_Info;
import com.nit.service.ICustomerService;

public class MainCustomerController {
private  ICustomerService icust;

public MainCustomerController(ICustomerService icust) {
	this.icust = icust;
}

public String processCustomer(Cust_Info cust)throws Exception {
	String result="";
	try {
		 result=icust.registerCustomer(cust);
		
	}
	catch(Exception e) {
		e.printStackTrace();
		throw e;
	}
	return result;
	
} 
	
}

