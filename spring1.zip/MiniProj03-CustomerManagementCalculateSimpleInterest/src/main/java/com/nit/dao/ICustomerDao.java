package com.nit.dao;

import com.nit.model.Cust_Info;

public interface ICustomerDao {
public int insert(Cust_Info cust)throws Exception;
}
