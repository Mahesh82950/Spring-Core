package com.nit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import com.nit.model.Cust_Info;

public class CustomerDaoImp implements ICustomerDao{
private DataSource dts;

	public CustomerDaoImp(DataSource dts) {
	this.dts = dts;
}
private static final String INSERT_QUERY="INSERT INTO CUST01 VALUES(?,?,?,?,?,?,?)";
int result=0;
	@Override
	public int insert(Cust_Info cust) throws Exception {
		try(Connection con=dts.getConnection();
				PreparedStatement psmt=con.prepareStatement(INSERT_QUERY);){
			psmt.setInt(1, cust.getCustId());
			psmt.setString(2, cust.getCustName());
			psmt.setString(3, cust.getCustAdd());
			psmt.setDouble(4, cust.getpAmount());
			psmt.setDouble(5, cust.getrInterest());
			psmt.setDouble(6, cust.getTime());
			psmt.setDouble(7, cust.getsInterest());
			result=psmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
			throw e;
			
		}
		return result;
	}

}
