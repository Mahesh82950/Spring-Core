package com.nit.factory;

import java.io.FileInputStream;
import java.lang.reflect.Constructor;
import java.util.Properties;

import com.nit.com.Courior;
import com.nit.com.Flipkart;

public class FlipkartFactory {
	private static Properties prop;
	static {
		try (FileInputStream fis = new FileInputStream("src/main/java/com/nit/commans/info.properties");) {
			prop = new Properties();
			prop.load(fis);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Flipkart createFlipkart() throws Exception {
		Flipkart fpkt = new Flipkart();
		Class c = Class.forName(prop.getProperty("dependent.comp"));
		Constructor con[] = c.getDeclaredConstructors();
		Courior courior = (Courior) con[0].newInstance();
		fpkt.setCourior(courior);
		return fpkt;
	}
}
