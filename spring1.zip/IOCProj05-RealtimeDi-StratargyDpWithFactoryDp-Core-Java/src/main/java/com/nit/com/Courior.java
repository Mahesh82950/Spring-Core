package com.nit.com;

public interface Courior {

	public String deliver(int ordID);
}
