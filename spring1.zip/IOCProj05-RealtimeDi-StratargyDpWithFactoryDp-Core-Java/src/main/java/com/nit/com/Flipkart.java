package com.nit.com;

import java.util.Arrays;
import java.util.Random;

public class Flipkart {
private Courior courior;

public void setCourior(Courior courior) {
	this.courior = courior;
}

public Flipkart() {
	System.out.println("Flipkart.:: 0-param Costructor");
}
public String shopping(float prices[],String items[]) {
	float totalAmt=0;
	for(int i=0;i<prices.length;i++) {
		totalAmt+=prices[i];}
		int ordId=new Random().nextInt(1000000);
		String status=courior.deliver(ordId);
		return Arrays.toString(items)+"\nAbove Items Are purchesed with prices of "+Arrays.toString(prices)+" \nThe Total Billl Amount is :: "+totalAmt+"\n"+status;
	
}

}
