package com.nit.test;

import com.nit.com.Flipkart;
import com.nit.factory.FlipkartFactory;

public class StatergyDpTest {
public static void main(String[] args) {
	try {
		Flipkart fpkt=FlipkartFactory.createFlipkart();
		String result=fpkt.shopping(new float[] {2000.0f,1200.0f,2300.0f}, new String[] {"Shirt","Trouser","Shoes"});
		System.out.println("Purched Items are ::"+result);
	} catch (Exception e) {
		
		e.printStackTrace();
	}
}
}
