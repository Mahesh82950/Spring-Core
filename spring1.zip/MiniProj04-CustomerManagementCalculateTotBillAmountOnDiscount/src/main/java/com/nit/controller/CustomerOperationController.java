package com.nit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.nit.model.CustomerInfo;
import com.nit.service.ICUstomerMgmtService;

@Controller("custController")
public class CustomerOperationController {
	@Autowired
private ICUstomerMgmtService icust;
	public String  processCustomer(CustomerInfo Cust)throws Exception{
		String result=icust.registerCust(Cust);
		return result;
	}
}
