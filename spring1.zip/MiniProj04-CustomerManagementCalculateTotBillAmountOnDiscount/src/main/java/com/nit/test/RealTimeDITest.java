package com.nit.test;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.controller.CustomerOperationController;
import com.nit.model.CustomerInfo;

public class RealTimeDITest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Customer Id :: ");
		int cid = sc.nextInt();
		System.out.println("Enter Customer Name :: ");
		String cname = sc.next();
		System.out.println("Enter Customer Address :: ");
		String cadd = sc.next();
		System.out.println("Enter Customer BillAmount ::");
		double billamount = sc.nextDouble();
		System.out.println("Enetr Customer Discount Percentage ::");
		double discount = sc.nextDouble();
		CustomerInfo cust = new CustomerInfo();
		cust.setCid(cid);
		cust.setCname(cname);
		cust.setCadd(cadd);
		cust.setBillAmount(billamount);
		cust.setDiscount(discount);
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml");
		CustomerOperationController custOpr = ctx.getBean("custController", CustomerOperationController.class);
		try {
			System.out.println(custOpr.processCustomer(cust));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ctx.close();
		sc.close();
	}
}
