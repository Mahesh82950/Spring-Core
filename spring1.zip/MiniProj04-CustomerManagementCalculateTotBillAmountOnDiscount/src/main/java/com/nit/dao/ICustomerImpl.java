package com.nit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nit.model.CustomerInfo;
@Repository("custDAO")
public class ICustomerImpl implements ICustomerDao {
	private static final String CUSTOMER_INFO_INSERT_QUERY="Insert into customer_info values(?,?,?,?,?,?)";
	@Autowired
private DataSource ds;
	int result=0;
	@Override
	public int insert(CustomerInfo cust) throws Exception {
		try(Connection con=ds.getConnection();
				PreparedStatement ps=con.prepareCall(CUSTOMER_INFO_INSERT_QUERY);){
			ps.setInt(1, cust.getCid());
			ps.setString(2, cust.getCname());
			ps.setString(3, cust.getCadd());
			ps.setDouble(4, cust.getBillAmount());
			ps.setDouble(5, cust.getDiscount());
			ps.setDouble(6, cust.getTotalAmount());
			result=ps.executeUpdate();
			
		}
		catch(SQLException e){
			e.printStackTrace();
			throw e;
		}
		catch(Exception ee) {
			ee.printStackTrace();
			throw ee;
		}
		return result;
	}

}
