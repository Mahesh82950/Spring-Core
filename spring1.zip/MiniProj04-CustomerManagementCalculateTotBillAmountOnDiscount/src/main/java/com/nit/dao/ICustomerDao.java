package com.nit.dao;

import com.nit.model.CustomerInfo;

public interface ICustomerDao {
 
	public int insert(CustomerInfo cust)throws Exception;
}
