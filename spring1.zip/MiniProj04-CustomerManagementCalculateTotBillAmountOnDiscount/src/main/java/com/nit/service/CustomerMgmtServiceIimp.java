package com.nit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.dao.ICustomerDao;
import com.nit.model.CustomerInfo;
@Service("CustService")
public class CustomerMgmtServiceIimp implements ICUstomerMgmtService{
	@Autowired
private ICustomerDao custDao;
	@Override
	public String registerCust(CustomerInfo cust) throws Exception {
		double discAmount=cust.getBillAmount()*(cust.getDiscount()/100.0);
		double FinalAmount=cust.getBillAmount()-discAmount;
		cust.setTotalAmount(FinalAmount);
		int count=custDao.insert(cust);
		return count==0?"Registration Faliled Please Try Again":"Customer Register With Bill Amount :: "+cust.getBillAmount()+" Discount Amount :: "+cust.getDiscount()+" Final Amount :: "+FinalAmount;
	}

}
