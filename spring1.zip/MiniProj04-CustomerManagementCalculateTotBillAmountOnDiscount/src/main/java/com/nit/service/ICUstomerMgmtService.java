package com.nit.service;

import com.nit.model.CustomerInfo;

public interface ICUstomerMgmtService {
public String registerCust(CustomerInfo cust)throws Exception;
}
