package com.nit.model;

public class CustomerInfo {
private Integer cid;
private String cname;
private String cadd;
private Double billAmount;
private Double discount;
private Double totalAmount;
public Integer getCid() {
	return cid;
}
public void setCid(Integer cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getCadd() {
	return cadd;
}
public void setCadd(String cadd) {
	this.cadd = cadd;
}
public Double getBillAmount() {
	return billAmount;
}
public void setBillAmount(Double billAmount) {
	this.billAmount = billAmount;
}
public Double getDiscount() {
	return discount;
}
public void setDiscount(Double discount) {
	this.discount = discount;
}
public Double getTotalAmount() {
	return totalAmount;
}
public void setTotalAmount(Double totalAmount) {
	this.totalAmount = totalAmount;
}

}
