package com.nit.sbeans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
@Controller("b1")
public class B {
	@Autowired
	private A a;
	
//	@Autowired
//	public B(A a) {
//		System.out.println("B.Custroctor");
//		this.a = a;
//	}
//	private A a;
//	@Autowired
//	public void assign(A a) {
//		this.a=a;
//	}

@Override
public String toString() {
	return "B [a= B class toString()]";
}

	
}
