package com.nit.sbeans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
@Controller("a1")
public class A {
@Autowired
	private B b;
	
//@Autowired
//	public A(B b) {
//		System.out.println("A.Class Custroctor");
//		this.b = b;
//	}
//	private B b;
//	@Autowired
//	public void assign(B b) {
//		this.b=b;
//	}
@Override
public String toString() {
	return "A [b= A class toString()]";
}
	
}
