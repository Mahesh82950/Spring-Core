package com.nit.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.sbeans.B;

public class CyclicDi_Using_ArbitaryMethod {

		public static void main(String[] args) {
			ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml");
			B a2=ctx.getBean("b1", B.class);
			System.out.println(a2+"Arbitary-Method-Injection");
			ctx.close();
		}
}
