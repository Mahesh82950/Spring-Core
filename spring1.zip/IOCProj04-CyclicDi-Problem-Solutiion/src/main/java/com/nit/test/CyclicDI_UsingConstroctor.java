package com.nit.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.sbeans.A;

public class CyclicDI_UsingConstroctor {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml");
		A a0=ctx.getBean("a1", A.class);
		System.out.println(a0+"Constructor");//throws Exception.....can be solved using....i)Field IJctn...ii)SetterInjection...iii)Arbitary-MethodInj
		ctx.close();
	}
}
