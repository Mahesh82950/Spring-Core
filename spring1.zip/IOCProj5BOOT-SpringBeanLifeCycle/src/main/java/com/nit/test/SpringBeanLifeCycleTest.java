package com.nit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nit.config.AppConfig;
import com.nit.sbeans.CheckVoterEligiblity;

public class SpringBeanLifeCycleTest {
public static void main(String[] args) {
	AnnotationConfigApplicationContext acc=new AnnotationConfigApplicationContext(AppConfig.class);
	CheckVoterEligiblity voterEligiblity=acc.getBean("voter", CheckVoterEligiblity.class);
	String result=voterEligiblity.checkEligiblity();
	System.out.println(result);
	acc.close();
}
}
