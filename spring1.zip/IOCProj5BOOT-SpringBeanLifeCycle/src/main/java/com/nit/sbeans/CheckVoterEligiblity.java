package com.nit.sbeans;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

@Component("voter")
@PropertySource("com/nit/commans/info.properties")
public class CheckVoterEligiblity {
	@Value("${per.id}")
	private long pid;
	@Value("${per.name}")
	private String name;
	@Value("${per.age}")
	private int age;
	private Date date;

	public CheckVoterEligiblity() {
		System.out.println("CheckVoterEligiblity:: 0-param constructor...");
	}

	@PostConstruct
	public void myInit() {
		System.out.println("myInit():: Executed...");
		if ((age > 120 && age < 1) || name == null) {
			throw new IllegalArgumentException("Please provide valid details....");
		}
		date = new Date();
	}

	public String checkEligiblity() {
		if (age >= 18) {
			return name + " is Eligible for Voting Verified age " + age + " on Date :: " + date + " UserId:: " + pid;
		} else {
			return name + " is Not Eligible for Voting Verified age " + age + " on Date :: " + date + " UserId:: "
					+ pid;
		}
	}

	@PreDestroy
	public void myDestroy() {
		System.out.println("myDestroy():: Executed.....");
		name = null;
		age = 0;
		pid = 0;
		date = null;
	}

}
