package com.nit.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("vehical")
public class Vehical {
	@Autowired
	@Qualifier("petrol")
 private Engine engine;

	public Vehical() {
		System.out.println("Vehical:: 0 param Constructor...");
	}
	public void journey(String startDest,String stopDest) {
		System.out.println("Journey Strated From -- "+startDest);
		engine.start();
		System.out.println("Journey Stopped At -- "+stopDest);
		engine.stop();
	}
	
	
}
