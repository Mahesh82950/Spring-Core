package com.nit.beans;

public interface Engine {
public void start();
public void stop();
}
