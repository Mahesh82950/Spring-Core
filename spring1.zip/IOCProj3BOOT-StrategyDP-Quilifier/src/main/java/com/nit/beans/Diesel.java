package com.nit.beans;

import org.springframework.stereotype.Component;

@Component("diesel")
//@Primary
public class Diesel implements Engine {

	public Diesel() {
		System.out.println("Diesel:: 0 Param Constructor....");
	}

	@Override
	public void start() {
		System.out.println("Diesel:: Diesel Engine Started....");
	}

	@Override
	public void stop() {
		System.out.println("Diesel:: Diesel Engine Stopped....");
	}

}
