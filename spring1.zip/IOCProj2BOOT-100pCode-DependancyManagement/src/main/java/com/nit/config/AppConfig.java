package com.nit.config;

import java.time.LocalDate;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com")
public class AppConfig {

	public AppConfig() {
		super();
		System.out.println("AppConfig::0-param Constructor");
	}
	@Bean
	public LocalDate getHours() {
		return LocalDate.now();
	}
	

}
