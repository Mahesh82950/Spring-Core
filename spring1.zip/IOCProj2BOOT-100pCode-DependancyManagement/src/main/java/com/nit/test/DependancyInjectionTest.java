package com.nit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nit.config.AppConfig;
import com.nit.sbeans.SeasonFinder;

public class DependancyInjectionTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(AppConfig.class);
		SeasonFinder s1=ctx.getBean("sf",SeasonFinder.class);
		String result = s1.findSeason("Mahesh");
		System.out.println(result);
		ctx.close();
	}
}
