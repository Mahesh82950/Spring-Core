package demo01;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Demo001 {
public static void main(String[] args){
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java", "root", "root");
	   PreparedStatement p1=con.prepareStatement("insert into product values(?,?,?,?)");
	   Scanner ms=new Scanner(System.in);
	   
	    int n=5;
	    while(n!=0) {
	    	System.out.println("Enter product id , Name ,price , Quentity ");
		    int id=ms.nextInt();
		    String name=ms.next();
		    int price=ms.nextInt();
		    int qty=ms.nextInt();
		    p1.setInt(1,id);
		    p1.setString(2, name);
		    p1.setInt(3, price);
		    p1.setInt(4, qty);
		    p1.executeUpdate();
	        System.out.println("Values Inserted...");
	        n--;
}
}
catch(Exception e)
	{
		e.printStackTrace();
	}
}
}