package com.nit.sbeans;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("wmg")
public class WishMAssageGenarator {
private LocalDateTime ldt;


public WishMAssageGenarator() {
	System.out.println("0 param Constructor WishMAsssageGenerator");
}
@Autowired
public void setLdt(LocalDateTime ldt) {	
	System.out.println("WishMAssageGenarator.setLdt()");
	this.ldt = ldt;
}
	public String generateWishMAssage(String user) {
		System.out.println("WishMAssageGenarator.generateWishMAssage()");
		int hours=ldt.getHour();
		if(hours<12) return "Good Morning : "+user;
		else if(hours<16) return "Good Afternoon :" +user;
		else if(hours<20)return "Good Evening :"+user;
		else return "Good Night : "+user;
	}

}
