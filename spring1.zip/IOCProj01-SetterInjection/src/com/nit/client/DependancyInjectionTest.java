package com.nit.client;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.nit.sbeans.WishMAssageGenarator;

public class DependancyInjectionTest {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
				"com/nit/cfgs/applicationContext.xml");
		WishMAssageGenarator w1 = ctx.getBean("wmg", WishMAssageGenarator.class);
		String result = w1.generateWishMAssage("Mahesh");
		System.out.println(result);
		 System.out.println(w1.hashCode());
		
		WishMAssageGenarator w2 = ctx.getBean("wmg", WishMAssageGenarator.class);
		 System.out.println(w2.hashCode());

		
		/*
		 * WishMAssageGenarator w2=ctx.getBean("wmg",WishMAssageGenarator.class);
		 System.out.println(w1==w2);
		 * System.out.println(w1.hashCode()+" "+w2.hashCode()); ctx.close();
		 */
	}
}
