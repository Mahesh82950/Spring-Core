package com.nit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.employeeDAO.IEmployeeDao;
import com.nit.model.Employee_Details;

@Service("sempService")
public class EmpMGMTServiceImp implements IEmpMGMTServices {
	@Autowired
	private IEmployeeDao empDao;

	@Override
	public String registerEmp(Employee_Details emp) throws Exception {
		int result = empDao.insert(emp);
		return result == 0 ? "Employee Registration Failed" : "Employee Registered With Details :" + emp.toString();
	}

}
