package com.nit.service;

import com.nit.model.Employee_Details;

public interface IEmpMGMTServices {
	public String registerEmp(Employee_Details emp)throws Exception;
}

