package com.nit.model;

public class Employee_Details {
private Integer empid;
private String ename;
private String eadd;
private String designation;
private Double salary;
public Integer getEmpid() {
	return empid;
}
public void setEmpid(Integer empid) {
	this.empid = empid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public String getEadd() {
	return eadd;
}
public void setEadd(String eadd) {
	this.eadd = eadd;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public Double getSalary() {
	return salary;
}
public void setSalary(Double salary) {
	this.salary = salary;
}
@Override
public String toString() {
	return "Employee_Details [empid=" + empid + ", ename=" + ename + ", eadd=" + eadd + ", designation=" + designation
			+ ", salary=" + salary + "]";
}


}
