package com.nit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.nit.model.Employee_Details;
import com.nit.service.IEmpMGMTServices;

@Controller("empController")
public class EmployeeOperationController {
	@Autowired
private IEmpMGMTServices istu;
	public String  processCustomer(Employee_Details emp)throws Exception{
		String result=istu.registerEmp(emp);
		return result;
	}

}