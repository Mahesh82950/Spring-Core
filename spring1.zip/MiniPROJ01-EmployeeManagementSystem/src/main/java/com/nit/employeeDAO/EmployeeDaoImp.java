package com.nit.employeeDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nit.model.Employee_Details;
@Repository("empDAO")
public class EmployeeDaoImp implements IEmployeeDao {
	private static final String QUERY = "INSERT INTO EMPLOYEE01 VALUES(?,?,?,?,?)";
	int count = 0;
	@Autowired
	private DataSource ds;

	@Override
	public int insert(Employee_Details emp) throws Exception {
		try (Connection con = ds.getConnection(); PreparedStatement ps = con.prepareStatement(QUERY)) {
			ps.setInt(1, emp.getEmpid());
			ps.setString(2, emp.getEname());
			ps.setString(3, emp.getEadd());
			ps.setString(4, emp.getDesignation());
			ps.setDouble(5, emp.getSalary());
			count = ps.executeUpdate();
		}
		return count;
	}

}
