package com.nit.employeeDAO;

import com.nit.model.Employee_Details;

public interface IEmployeeDao {
public int insert(Employee_Details emp)throws Exception;
}
