package com.nit.test;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.controller.EmployeeOperationController;
import com.nit.model.Employee_Details;

public class RealTimeMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee ID :");
		int empid=sc.nextInt();
		System.out.println("Enter Employee NAME :");
		String empName=sc.next();
		System.out.println("Enter Employee Address :");
		String empAdd=sc.next();
		System.out.println("Enter Employee Designation :");
		String designation=sc.next();
		System.out.println("Enter Employee Salary :");
		double salary=sc.nextDouble();
		Employee_Details emp=new Employee_Details();
		emp.setEmpid(empid);
		emp.setEname(empName);
		emp.setEadd(empAdd);
		emp.setDesignation(designation);;
		emp.setSalary(salary);
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml");
		EmployeeOperationController empc=ctx.getBean("empController", EmployeeOperationController.class);
		try {
			System.out.println(empc.processCustomer(emp));
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		ctx.close();
		sc.close();
	}
	
}
