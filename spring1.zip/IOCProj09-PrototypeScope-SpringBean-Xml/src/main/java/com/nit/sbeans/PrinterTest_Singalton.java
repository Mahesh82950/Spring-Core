package com.nit.sbeans;

public class PrinterTest_Singalton {
private PrinterTest_Singalton() {
	System.out.println("PrinterTest_Singalton::0-param Constructor");
}
public static PrinterTest_Singalton printer;
public static PrinterTest_Singalton getInstance() {
	if(printer==null)printer=new PrinterTest_Singalton();
	return printer;
}
public void print() {
	System.out.println("Singalton Instance Method...can be Accessible using factory bean method");
}
}