package com.nit.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nit.sbeans.PrinterTest_Singalton;

public class SingaltonScopeSpringTest {
public static void main(String[] args) {
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nit/cfgs/applicationContext.xml");
	PrinterTest_Singalton prin1=ctx.getBean("p1", PrinterTest_Singalton.class);
	prin1.print();
	PrinterTest_Singalton prin2=ctx.getBean("p1", PrinterTest_Singalton.class);
	prin2.print();
	System.out.println(prin1.hashCode()+"\n "+prin2.hashCode());
	ctx.close();
}
}

