package com.nit.config;

import java.time.LocalDateTime;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.nit")
public class AppConfig {
	public AppConfig() {
		super();
		System.out.println("AppConfig::0-param Constructor");
	}
	@Bean
	public LocalDateTime getHours() {
		return LocalDateTime.now();
	}
	

}
