package com.nit.sbeans;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("wmg")
public class WishMassageGenerator {
	@Autowired
	private LocalDateTime ldt;

	public WishMassageGenerator() {
		System.out.println("WishMassageGenerator-0 Param-contructor()");
	}

	public String genarateWish(String user) {
		int hours = ldt.getHour();
		if (hours < 12)
			return "Good Morning : " + user;
		else if (hours < 16)
			return "Good Afternoon :" + user;
		else if (hours < 20)
			return "Good Evening :" + user;
		else
			return "Good Night : " + user;
	}
}
