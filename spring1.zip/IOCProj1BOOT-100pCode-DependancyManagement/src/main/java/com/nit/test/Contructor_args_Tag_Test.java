package com.nit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nit.config.AppConfig;
import com.nit.sbeans.WishMassageGenerator;

public class Contructor_args_Tag_Test {
public static void main(String[] args) {
	AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(AppConfig.class);
	WishMassageGenerator generator=ctx.getBean("wmg", WishMassageGenerator.class);
	System.out.println(generator.genarateWish("mahesh"));
	ctx.close();
}
}

